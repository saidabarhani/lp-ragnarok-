# ⚔️ Landing Page Officielle — Ragnarok : Chronicles of Midgard

Une page d'atterrissage (Landing Page) professionnelle, immersive et orientée conversion conçue pour inciter les internautes à installer le jeu légendaire **Ragnarok**.

---

## 🎯 Respect du Brief & Message Clé

La page intègre fidèlement l'intégralité du texte et de la structure demandés :

* **Objet / Titre d'accroche :** *« Découvrez l'univers captivant de Ragnarok et installez-le dès maintenant ! »*
* **Message de bienvenue personnalisé :** *« Bonjour [Nom] »* — Avec un système interactif permettant d'injecter dynamiquement le pseudo ou nom de l'internaute (via URL `?nom=VotreNom` ou via le bouton de personnalisation).
* **Présentation de l'univers :** Mise en valeur des *graphismes enchanteurs* et de la *jouabilité immersive*, des quêtes épiques et des aventures inoubliables.
* **Le Guide d'Installation en 4 Étapes Simples :**
  1. **Téléchargez le client du jeu :** Bouton direct de téléchargement du client officiel avec sélecteur de plateforme (Windows, macOS, Mobile) et liens miroirs.
  2. **Installez le jeu :** Guide pas-à-pas pour ouvrir le fichier téléchargé et compléter l'installation.
  3. **Créez votre compte :** Formulaire de pré-inscription rapide avec bonus de bienvenue offert (Chapeau Poring, potions, monture).
  4. **Connectez-vous et commencez à jouer :** Lancement direct dans l'univers de Rune-Midgard.
* **Appel final à la communauté & Assistance :** Liens Discord, Twitch, FAQ interactive et modal d'assistance dédiée sous 15 minutes.

---

## 📁 Structure du Projet

```text
lp ragnarok/
├── index.html          # Structure sémantique HTML5 complète et accessible
├── css/
│   └── style.css       # Design System Dark Fantasy, Glassmorphism & Responsive Design
├── js/
│   └── main.js         # Moteur interactif (Canvas runes, Audio synthétisé, Modales, Simulateur)
└── README.md           # Documentation et guide d'utilisation
```

---

## 🚀 Fonctionnalités & Expérience Gaming

1. **Effets Audio RPG Interactifs (Web Audio API) :**
   - Synthétiseur audio pur en JavaScript (aucun fichier MP3/WAV externe requis, aucun risque de lien mort).
   - Sons de clics fantastiques, carillon iconique de *Level-Up*, son de portail de téléportation.
   - Bouton de bascule Audio (ON/OFF) avec persistance dans le navigateur (`localStorage`).

2. **Arrière-plan Ambiant Animé (Canvas HTML5) :**
   - Étincelles dorées et braises runiques montant délicatement en arrière-plan pour une ambiance féerique.

3. **Sélecteur de Classes Interactif :**
   - Navigation fluide entre 6 classes emblématiques : *Lord Knight*, *High Wizard*, *Assassin Cross*, *High Priest*, *Sniper*, et *Whitesmith*.
   - Affichage dynamique des jauges de statistiques (Survie, Dégâts, Magie, Difficulté), compétences signatures et citations.

4. **Simulateur de Téléchargement & Modale Complète :**
   - Barre de progression réaliste avec calcul de vitesse, vérification de hash SHA-256 et déclenchement du fichier d'instructions.
   - Sélection multi-plateforme : Windows 10/11 (64-bit), macOS Silicon/Intel, Mobile Android/iOS.

5. **Diagnostic de Configuration Système :**
   - Table comparative claire : Configuration Minimale vs Recommandée.

6. **FAQ interactive en Accordéon & Formulaire de Support :**
   - Réponses directes aux questions fréquentes (gratuité du jeu, problèmes de pare-feu/antivirus, cross-play).
   - Formulaire d'assistance avec retour visuel immédiat.

7. **Compteur de Joueurs Connectés en Temps Réel :**
   - Simulation dynamique de l'affluence du serveur *Midgard-Prime* (+/- fluctuations).

---

## 💻 Comment Ouvrir et Tester la Landing Page

1. **Ouverture directe dans un navigateur :**
   - Double-cliquez simplement sur le fichier `index.html` ou ouvrez-le avec votre navigateur web préféré (Chrome, Firefox, Edge, Safari).

2. **Personnalisation par URL :**
   - Vous pouvez tester l'accueil personnalisé directement en ouvrant l'URL :
     `index.html?nom=Thomas` ou `index.html?nom=Valkyrie`
   - Le message d'accroche affichera automatiquement : **« Bonjour Thomas, votre destin commence ici »**.

/**
 * ==========================================================================
 * RAGNAROK ONLINE — CHRONICLES OF MIDGARD
 * Interactive Landing Page Engine (Vanilla JavaScript)
 * ==========================================================================
 */

document.addEventListener('DOMContentLoaded', () => {
  'use strict';

  // ------------------------------------------------------------------------
  // 1. WEB AUDIO API SYNTHESIZER (IMMERSIVE GAMING SFX)
  // ------------------------------------------------------------------------
  class RpgAudioSystem {
    constructor() {
      this.ctx = null;
      this.enabled = localStorage.getItem('ragnarok_sfx') !== 'false';
      this.initUi();
    }

    initContext() {
      if (!this.ctx) {
        const AudioCtx = window.AudioContext || window.webkitAudioContext;
        if (AudioCtx) {
          this.ctx = new AudioCtx();
        }
      }
      if (this.ctx && this.ctx.state === 'suspended') {
        this.ctx.resume();
      }
    }

    toggle() {
      this.enabled = !this.enabled;
      localStorage.setItem('ragnarok_sfx', this.enabled);
      this.updateUi();
      if (this.enabled) {
        this.playClick();
      }
    }

    initUi() {
      const toggleBtn = document.getElementById('soundToggle');
      if (toggleBtn) {
        toggleBtn.addEventListener('click', () => this.toggle());
      }
      this.updateUi();
    }

    updateUi() {
      const statusEl = document.getElementById('soundStatus');
      const iconEl = document.getElementById('soundIcon');
      if (statusEl && iconEl) {
        if (this.enabled) {
          statusEl.textContent = 'ON';
          iconEl.className = 'fa-solid fa-volume-high text-gold';
        } else {
          statusEl.textContent = 'OFF';
          iconEl.className = 'fa-solid fa-volume-xmark text-dim';
        }
      }
    }

    // Fantasy UI Click Sound
    playClick() {
      if (!this.enabled) return;
      this.initContext();
      if (!this.ctx) return;

      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      const now = this.ctx.currentTime;

      osc.type = 'sine';
      osc.frequency.setValueAtTime(587.33, now); // D5
      osc.frequency.exponentialRampToValueAtTime(880, now + 0.08); // A5

      gain.gain.setValueAtTime(0.12, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.09);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start(now);
      osc.stop(now + 0.09);
    }

    // Iconic Ragnarok Level-Up Chime Arpeggio
    playLevelUp() {
      if (!this.enabled) return;
      this.initContext();
      if (!this.ctx) return;

      const notes = [523.25, 659.25, 783.99, 1046.50, 1318.51, 1567.98]; // C5, E5, G5, C6, E6, G6
      const now = this.ctx.currentTime;

      notes.forEach((freq, idx) => {
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        const noteStart = now + idx * 0.07;

        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, noteStart);

        gain.gain.setValueAtTime(0.14, noteStart);
        gain.gain.exponentialRampToValueAtTime(0.0001, noteStart + 0.35);

        osc.connect(gain);
        gain.connect(this.ctx.destination);

        osc.start(noteStart);
        osc.stop(noteStart + 0.35);
      });
    }

    // Portal Warp / Rune Sound
    playWarp() {
      if (!this.enabled) return;
      this.initContext();
      if (!this.ctx) return;

      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      const now = this.ctx.currentTime;

      osc.type = 'sine';
      osc.frequency.setValueAtTime(220, now);
      osc.frequency.exponentialRampToValueAtTime(880, now + 0.4);

      gain.gain.setValueAtTime(0.1, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.45);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start(now);
      osc.stop(now + 0.45);
    }
  }

  const sfx = new RpgAudioSystem();

  // Attach sound to interactive buttons
  document.querySelectorAll('button, .nav-link, .class-tab-btn, .faq-question').forEach(el => {
    el.addEventListener('click', () => {
      sfx.playClick();
    });
  });

  // ------------------------------------------------------------------------
  // 2. AMBIENT PARTICLES (RUNE SPARKS & GOLDEN EMBERS)
  // ------------------------------------------------------------------------
  const canvas = document.getElementById('ambient-canvas');
  if (canvas) {
    const ctx = canvas.getContext('2d');
    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    window.addEventListener('resize', () => {
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    });

    const particles = [];
    const particleCount = Math.min(width < 768 ? 25 : 55, 60);

    class SparkParticle {
      constructor() {
        this.reset();
      }

      reset() {
        this.x = Math.random() * width;
        this.y = height + Math.random() * 50;
        this.size = Math.random() * 2.5 + 0.8;
        this.speedY = Math.random() * 0.9 + 0.3;
        this.speedX = (Math.random() - 0.5) * 0.5;
        this.alpha = Math.random() * 0.7 + 0.2;
        this.decay = Math.random() * 0.004 + 0.001;
        // 70% gold sparks, 30% rune cyan
        this.isGold = Math.random() > 0.3;
      }

      update() {
        this.y -= this.speedY;
        this.x += this.speedX;
        this.alpha -= this.decay;

        if (this.y < -10 || this.alpha <= 0) {
          this.reset();
        }
      }

      draw() {
        ctx.save();
        ctx.globalAlpha = Math.max(0, this.alpha);
        ctx.beginPath();
        ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
        ctx.fillStyle = this.isGold ? '#f59e0b' : '#38bdf8';
        ctx.shadowColor = this.isGold ? '#fbbf24' : '#0284c7';
        ctx.shadowBlur = 6;
        ctx.fill();
        ctx.restore();
      }
    }

    for (let i = 0; i < particleCount; i++) {
      const p = new SparkParticle();
      p.y = Math.random() * height; // Spread initially
      particles.push(p);
    }

    function animateSparks() {
      ctx.clearRect(0, 0, width, height);
      particles.forEach(p => {
        p.update();
        p.draw();
      });
      requestAnimationFrame(animateSparks);
    }
    animateSparks();
  }

  // ------------------------------------------------------------------------
  // 3. PERSONALIZED USERNAME / "BONJOUR [NOM]" ENGINE
  // ------------------------------------------------------------------------
  const heroUserName = document.getElementById('heroUserName');
  const navAventurierName = document.getElementById('navAventurierName');
  const nameModal = document.getElementById('nameModal');
  const btnPersonalize = document.getElementById('btnPersonalize');
  const welcomeGreeting = document.getElementById('welcomeGreeting');
  const closeNameModal = document.getElementById('closeNameModal');
  const saveCustomNameBtn = document.getElementById('saveCustomNameBtn');
  const customNameInput = document.getElementById('customNameInput');

  function updateDisplayedName(name) {
    const finalName = name && name.trim() ? name.trim() : 'Aventurier';
    if (heroUserName) heroUserName.textContent = finalName;
    if (navAventurierName) navAventurierName.textContent = finalName;
  }

  // Check LocalStorage or URL Query param ?name=Tristan
  const urlParams = new URLSearchParams(window.location.search);
  const queryName = urlParams.get('nom') || urlParams.get('name');
  const storedName = localStorage.getItem('ragnarok_player_name');

  if (queryName) {
    updateDisplayedName(queryName);
    localStorage.setItem('ragnarok_player_name', queryName);
  } else if (storedName) {
    updateDisplayedName(storedName);
  }

  function openNameModal() {
    if (nameModal) {
      nameModal.classList.add('active');
      if (customNameInput) {
        customNameInput.value = storedName || '';
        setTimeout(() => customNameInput.focus(), 150);
      }
    }
  }

  function closeCustomNameModal() {
    if (nameModal) nameModal.classList.remove('active');
  }

  if (btnPersonalize) btnPersonalize.addEventListener('click', openNameModal);
  if (welcomeGreeting) welcomeGreeting.addEventListener('click', openNameModal);
  if (closeNameModal) closeNameModal.addEventListener('click', closeCustomNameModal);

  if (saveCustomNameBtn && customNameInput) {
    saveCustomNameBtn.addEventListener('click', () => {
      const val = customNameInput.value.trim();
      if (val) {
        updateDisplayedName(val);
        localStorage.setItem('ragnarok_player_name', val);
        sfx.playLevelUp();
      }
      closeCustomNameModal();
    });

    customNameInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        saveCustomNameBtn.click();
      }
    });
  }

  // ------------------------------------------------------------------------
  // 4. CLASS PREVIEW SHOWCASE DATA & INTERACTION
  // ------------------------------------------------------------------------
  const classDatabase = {
    knight: {
      role: 'Guerrier de Première Ligne • Tank & Dégâts',
      name: 'Lord Knight (Chevalier Runique)',
      desc: "Maître d'armes capable de trancher des armées entières sur le dos de son Peco Peco. Doté d'une résistance herculéenne et de compétences dévastatrices au corps-à-corps comme Bowling Bash et Spiral Pierce.",
      def: '95%',
      atk: '90%',
      mag: '25%',
      diff: 'Facile (30%)',
      diffVal: '30%',
      icon: 'fa-shield',
      quote: '« Rien ne percera ma ligne de front. Pour la gloire de Prontera ! »',
      skills: ['Bowling Bash', 'Spiral Pierce', 'Frenzy / Berserk']
    },
    wizard: {
      role: 'Maître Élémentaire • Dégâts de Zone Massifs',
      name: 'High Wizard (Archimage Suprême)',
      desc: "Invoque la colère des éléments. Du déluge de météores de Meteor Storm aux congélations mortelles de Storm Gust, l'Archimage anéantit des cohortes d'ennemis à distance.",
      def: '40%',
      atk: '35%',
      mag: '100%',
      diff: 'Moyen (65%)',
      diffVal: '65%',
      icon: 'fa-hat-wizard',
      quote: '« Les cieux grondent et obéissent à mes incantations arcaniques. »',
      skills: ['Storm Gust', 'Meteor Storm', 'Lord of Vermilion']
    },
    assassin: {
      role: 'Ombre Mortelle • Vitesse & Coups Critiques',
      name: 'Assassin Cross (Maître Assassin)',
      desc: "Spécialiste de l'infiltration et des poisons mortels. Équipé de deux Katars ou dagues, il frappe avec une cadence fulgurante et déclenche le redoutable Sonic Blow.",
      def: '55%',
      atk: '98%',
      mag: '30%',
      diff: 'Expert (80%)',
      diffVal: '80%',
      icon: 'fa-khanda',
      quote: '« Vous ne sentirez même pas la morsure de mes lames dans la pénombre. »',
      skills: ['Sonic Blow', 'Soul Destroyer', 'Enchant Poison']
    },
    priest: {
      role: 'Protecteur Sacré • Guérison & Bénédictions',
      name: 'High Priest (Grand Prêtre de Frigg)',
      desc: "Pillier indispensable de tout groupe et de toute guilde. Il purifie les morts-vivants avec Magnus Exorcismus et confère les bénédictions légendaires Kyrie Eleison et Blessing.",
      def: '75%',
      atk: '30%',
      mag: '90%',
      diff: 'Accessible (45%)',
      diffVal: '45%',
      icon: 'fa-cross',
      quote: '« Que la lumière d’Odin et de Freya guide vos armes et apaise vos blessures. »',
      skills: ['Blessing & Agi Up', 'Kyrie Eleison', 'Magnus Exorcismus']
    },
    sniper: {
      role: 'Tireur d’Élite • Distance & Pièges Mortels',
      name: 'Sniper (Chasseur Mythique)',
      desc: "Accompagné de son fidèle faucon de combat, il crible ses cibles de flèches à des distances démesurées. Ses pièges contrôlent le champ de bataille avec une précision chirurgicale.",
      def: '50%',
      atk: '92%',
      mag: '40%',
      diff: 'Moyen (55%)',
      diffVal: '55%',
      icon: 'fa-bullseye',
      quote: '« Une seule flèche dans la tempête suffit à abattre le plus féroce des MVPs. »',
      skills: ['Arrow Shower', 'Falcon Assault', 'Sharp Shooting']
    },
    whitesmith: {
      role: 'Forge Légendaire • Maître Économique & Fracas',
      name: 'Whitesmith (Maître Forgeron)',
      desc: "Façonneur des armes les plus puissantes de Midgard et combattant féroce. Grâce à Cart Termination et Maximum Overthrust, il brise les armures adverses à coups de marteau.",
      def: '80%',
      atk: '95%',
      mag: '20%',
      diff: 'Tactique (70%)',
      diffVal: '70%',
      icon: 'fa-hammer',
      quote: '« Mon marteau forge les trésors des dieux et fracasse mes ennemis. »',
      skills: ['Cart Termination', 'Maximum Over Thrust', 'Weapon Refine']
    }
  };

  const classTabButtons = document.querySelectorAll('.class-tab-btn');
  const classRoleTag = document.getElementById('classRoleTag');
  const classNameTitle = document.getElementById('classNameTitle');
  const classDescription = document.getElementById('classDescription');
  const barDef = document.getElementById('barDef');
  const statDef = document.getElementById('statDef');
  const barAtk = document.getElementById('barAtk');
  const statAtk = document.getElementById('statAtk');
  const barMag = document.getElementById('barMag');
  const statMag = document.getElementById('statMag');
  const barDiff = document.getElementById('barDiff');
  const statDiff = document.getElementById('statDiff');
  const classQuote = document.getElementById('classQuote');
  const classLargeIcon = document.getElementById('classLargeIcon');

  function renderClass(classKey) {
    const data = classDatabase[classKey];
    if (!data) return;

    if (classRoleTag) classRoleTag.textContent = data.role;
    if (classNameTitle) classNameTitle.textContent = data.name;
    if (classDescription) classDescription.innerHTML = data.desc;

    if (barDef) barDef.style.width = data.def;
    if (statDef) statDef.textContent = data.def;

    if (barAtk) barAtk.style.width = data.atk;
    if (statAtk) statAtk.textContent = data.atk;

    if (barMag) barMag.style.width = data.mag;
    if (statMag) statMag.textContent = data.mag;

    if (barDiff) barDiff.style.width = data.diffVal;
    if (statDiff) statDiff.textContent = data.diff;

    if (classQuote) classQuote.textContent = data.quote;
    if (classLargeIcon) classLargeIcon.className = `fa-solid ${data.icon} fa-4x text-gold`;

    sfx.playWarp();
  }

  classTabButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      classTabButtons.forEach(b => {
        b.classList.remove('active');
        b.setAttribute('aria-selected', 'false');
      });
      btn.classList.add('active');
      btn.setAttribute('aria-selected', 'true');
      const classKey = btn.dataset.class;
      renderClass(classKey);
    });
  });

  // ------------------------------------------------------------------------
  // 5. DOWNLOAD MODAL & REALISTIC SIMULATOR
  // ------------------------------------------------------------------------
  const downloadModal = document.getElementById('downloadModal');
  const openDownloadBtns = document.querySelectorAll('.open-download-modal');
  const closeDownloadModal = document.getElementById('closeDownloadModal');
  const startDownloadTrigger = document.getElementById('startDownloadTrigger');
  const downloadProgressContainer = document.getElementById('downloadProgressContainer');
  const downloadProgressBar = document.getElementById('downloadProgressBar');
  const downloadProgressPercent = document.getElementById('downloadProgressPercent');
  const downloadProgressStatus = document.getElementById('downloadProgressStatus');
  const platformBtns = document.querySelectorAll('.platform-btn');

  function openDownload() {
    if (downloadModal) {
      downloadModal.classList.add('active');
      sfx.playClick();
    }
  }

  function closeDownload() {
    if (downloadModal) {
      downloadModal.classList.remove('active');
    }
  }

  openDownloadBtns.forEach(btn => btn.addEventListener('click', openDownload));
  if (closeDownloadModal) closeDownloadModal.addEventListener('click', closeDownload);

  // Platform switcher inside modal
  platformBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      platformBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const platform = btn.dataset.platform;
      const fileNameEl = document.querySelector('.file-name strong');
      if (fileNameEl) {
        if (platform === 'windows') {
          fileNameEl.textContent = 'Ragnarok_Installer_Setup_2026.exe';
        } else if (platform === 'macos') {
          fileNameEl.textContent = 'Ragnarok_Client_Mac_Silicon.dmg';
        } else {
          fileNameEl.textContent = 'Ragnarok_Mobile_Universal.apk';
        }
      }
    });
  });

  // Global helper for mirror links
  window.triggerSimulatedDownload = function(mirrorName) {
    if (startDownloadTrigger) {
      if (downloadProgressStatus) {
        downloadProgressStatus.textContent = `Connexion au ${mirrorName}...`;
      }
      startDownloadTrigger.click();
    }
  };

  // Simulated download progress animation
  if (startDownloadTrigger && downloadProgressBar) {
    startDownloadTrigger.addEventListener('click', () => {
      startDownloadTrigger.disabled = true;
      startDownloadTrigger.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Préparation...';
      downloadProgressContainer.style.display = 'block';

      let progress = 0;
      const interval = setInterval(() => {
        progress += Math.floor(Math.random() * 8) + 4;
        if (progress > 100) progress = 100;

        downloadProgressBar.style.width = progress + '%';
        if (downloadProgressPercent) downloadProgressPercent.textContent = progress + '%';

        if (downloadProgressStatus) {
          if (progress < 30) {
            downloadProgressStatus.textContent = 'Téléchargement des archives de jeu...';
          } else if (progress < 70) {
            downloadProgressStatus.textContent = 'Téléchargement des textures féeriques de Rune-Midgard...';
          } else if (progress < 99) {
            downloadProgressStatus.textContent = 'Vérification de l’intégrité SHA-256...';
          } else {
            downloadProgressStatus.textContent = 'Téléchargement terminé avec succès !';
          }
        }

        if (progress >= 100) {
          clearInterval(interval);
          sfx.playLevelUp();
          startDownloadTrigger.disabled = false;
          startDownloadTrigger.innerHTML = '<i class="fa-solid fa-circle-check"></i> Prêt ! Ouvrir l’Installeur';
          
          // Trigger actual safe download anchor for UX satisfaction
          try {
            const blob = new Blob([
              "=== RAGNAROK CLIENT LAUNCHER GUIDE ===\n\n" +
              "1. Merci d'avoir telecharge le client officiel de Ragnarok !\n" +
              "2. Pour installer le jeu, executez ce fichier d'installation en tant qu'administrateur.\n" +
              "3. Creez votre compte officiel et connectez-vous a Prontera.\n\n" +
              "Bienvenue dans l'univers captivant de Ragnarok !"
            ], { type: 'text/plain' });
            const tempLink = document.createElement('a');
            tempLink.href = URL.createObjectURL(blob);
            tempLink.download = 'Ragnarok_Installation_Readme.txt';
            document.body.appendChild(tempLink);
            tempLink.click();
            document.body.removeChild(tempLink);
          } catch (e) {
            console.log('Download trigger note', e);
          }

          // Highlight Step 2 on the landing page
          highlightStep(2);
        }
      }, 120);
    });
  }

  // ------------------------------------------------------------------------
  // 6. STEPPING HIGHLIGHT HELPER
  // ------------------------------------------------------------------------
  const stepCards = document.querySelectorAll('.step-card');
  function highlightStep(stepNum) {
    stepCards.forEach(card => {
      if (parseInt(card.dataset.step) === stepNum) {
        card.classList.add('active');
        card.scrollIntoView({ behavior: 'smooth', block: 'center' });
      } else {
        card.classList.remove('active');
      }
    });
  }

  stepCards.forEach(card => {
    card.addEventListener('click', () => {
      stepCards.forEach(c => c.classList.remove('active'));
      card.classList.add('active');
    });
  });

  // ------------------------------------------------------------------------
  // 7. PRE-REGISTRATION / STARTER CLAIM FORM
  // ------------------------------------------------------------------------
  const quickRegisterForm = document.getElementById('quickRegisterForm');
  const registerSuccessBox = document.getElementById('registerSuccessBox');
  const createdPlayerName = document.getElementById('createdPlayerName');

  if (quickRegisterForm) {
    quickRegisterForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const usernameInput = document.getElementById('regUsername');
      const playerVal = usernameInput ? usernameInput.value.trim() : 'Aventurier';

      // Update name everywhere
      updateDisplayedName(playerVal);
      localStorage.setItem('ragnarok_player_name', playerVal);

      if (createdPlayerName) createdPlayerName.textContent = playerVal;

      // Celebrate with Level-Up sound
      sfx.playLevelUp();

      // Switch form to success screen
      quickRegisterForm.style.display = 'none';
      if (registerSuccessBox) registerSuccessBox.style.display = 'block';

      // Mark step 4 ready
      highlightStep(4);
    });
  }

  // ------------------------------------------------------------------------
  // 8. FAQ ACCORDION
  // ------------------------------------------------------------------------
  const faqItems = document.querySelectorAll('.faq-item');
  faqItems.forEach(item => {
    const questionBtn = item.querySelector('.faq-question');
    if (questionBtn) {
      questionBtn.addEventListener('click', () => {
        const isActive = item.classList.contains('active');
        // Close other items
        faqItems.forEach(other => other.classList.remove('active'));
        if (!isActive) {
          item.classList.add('active');
        }
      });
    }
  });

  // ------------------------------------------------------------------------
  // 9. SUPPORT ASSISTANCE MODAL & FORM
  // ------------------------------------------------------------------------
  const supportModal = document.getElementById('supportModal');
  const openSupportBtns = document.querySelectorAll('.open-support-modal');
  const closeSupportModal = document.getElementById('closeSupportModal');
  const supportContactForm = document.getElementById('supportContactForm');
  const supportSuccessMsg = document.getElementById('supportSuccessMsg');

  function openSupport() {
    if (supportModal) {
      supportModal.classList.add('active');
      sfx.playClick();
    }
  }

  function closeSupport() {
    if (supportModal) supportModal.classList.remove('active');
  }

  openSupportBtns.forEach(btn => btn.addEventListener('click', openSupport));
  if (closeSupportModal) closeSupportModal.addEventListener('click', closeSupport);

  if (supportContactForm) {
    supportContactForm.addEventListener('submit', (e) => {
      e.preventDefault();
      supportContactForm.style.display = 'none';
      if (supportSuccessMsg) supportSuccessMsg.style.display = 'block';
      sfx.playLevelUp();
      setTimeout(() => {
        closeSupport();
        setTimeout(() => {
          supportContactForm.reset();
          supportContactForm.style.display = 'block';
          if (supportSuccessMsg) supportSuccessMsg.style.display = 'none';
        }, 500);
      }, 3500);
    });
  }

  // ------------------------------------------------------------------------
  // 10. TRAILER VIDEO MODAL
  // ------------------------------------------------------------------------
  const trailerModal = document.getElementById('trailerModal');
  const btnOpenTrailer = document.getElementById('btnOpenTrailer');
  const closeTrailerModal = document.getElementById('closeTrailerModal');

  if (btnOpenTrailer && trailerModal) {
    btnOpenTrailer.addEventListener('click', () => {
      trailerModal.classList.add('active');
      sfx.playWarp();
    });
  }

  if (closeTrailerModal && trailerModal) {
    closeTrailerModal.addEventListener('click', () => {
      trailerModal.classList.remove('active');
    });
  }

  // Close modals on escape key or backdrop click
  document.querySelectorAll('.modal-overlay').forEach(modal => {
    modal.addEventListener('click', (e) => {
      if (e.target === modal) {
        modal.classList.remove('active');
      }
    });
  });

  window.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      document.querySelectorAll('.modal-overlay').forEach(m => m.classList.remove('active'));
    }
  });

  // ------------------------------------------------------------------------
  // 11. MOBILE HAMBURGER MENU
  // ------------------------------------------------------------------------
  const mobileToggle = document.getElementById('mobileToggle');
  const navMenu = document.getElementById('navMenu');

  if (mobileToggle && navMenu) {
    mobileToggle.addEventListener('click', () => {
      navMenu.classList.toggle('open');
    });

    // Close when clicking a nav link
    navMenu.querySelectorAll('.nav-link').forEach(link => {
      link.addEventListener('click', () => {
        navMenu.classList.remove('open');
      });
    });
  }

  // ------------------------------------------------------------------------
  // 12. NAVBAR SCROLL EFFECT
  // ------------------------------------------------------------------------
  const header = document.getElementById('header');
  window.addEventListener('scroll', () => {
    if (header) {
      if (window.scrollY > 40) {
        header.classList.add('scrolled');
      } else {
        header.classList.remove('scrolled');
      }
    }
  });

  // ------------------------------------------------------------------------
  // 13. LIVE SERVER PLAYERS COUNTER TICKER
  // ------------------------------------------------------------------------
  const onlineCountEl = document.getElementById('onlineCount');
  if (onlineCountEl) {
    let count = 14892;
    setInterval(() => {
      const delta = Math.floor(Math.random() * 11) - 5; // -5 to +5
      count += delta;
      onlineCountEl.textContent = count.toLocaleString('fr-FR');
    }, 4000);
  }

  console.log('⚔️ Ragnarok Chronicles engine initialized with success !');
});

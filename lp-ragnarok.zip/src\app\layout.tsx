import type { Metadata } from 'next';
import { Cinzel, Orbitron, Outfit } from 'next/font/google';
import './globals.css';

const cinzel = Cinzel({
  subsets: ['latin'],
  variable: '--font-cinzel',
  weight: ['400', '600', '700', '800', '900'],
  display: 'swap',
});

const orbitron = Orbitron({
  subsets: ['latin'],
  variable: '--font-orbitron',
  weight: ['400', '600', '700', '800', '900'],
  display: 'swap',
});

const outfit = Outfit({
  subsets: ['latin'],
  variable: '--font-outfit',
  weight: ['300', '400', '500', '600', '700', '800'],
  display: 'swap',
});

export const metadata: Metadata = {
  title: 'Ragnarok: The New World — Discover the Captivating Universe & Install Now',
  description:
    'Join millions of players in Ragnarok: The New World by Gravity. High-definition 30 GB open world MMORPG with full cross-play on PC Steam and Mobile. Featuring 8 classes including Druid.',
  keywords: [
    'Ragnarok',
    'Ragnarok The New World',
    'Gravity Game Vision',
    'Steam MMORPG',
    'Google Play Ragnarok',
    'Druid Class Ragnarok',
    'Midgard',
    'Ragnarok PC 30GB',
  ],
  openGraph: {
    title: 'Ragnarok: The New World — Discover the Captivating Universe',
    description:
      'Return to Midgard on your own terms. Free-to-play open world on Steam & Mobile.',
    type: 'website',
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" data-theme="neo-dark" className="scroll-smooth">
      <body
        className={`${cinzel.variable} ${orbitron.variable} ${outfit.variable} antialiased selection:bg-amber-400 selection:text-black`}
      >
        {children}
      </body>
    </html>
  );
}

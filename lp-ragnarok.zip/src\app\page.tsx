'use client';

import React, { useState, useEffect } from 'react';
import { SupportedLocale, translations } from '@/lib/i18n';
import { Navbar } from '@/components/Navbar';
import { HeroSection } from '@/components/HeroSection';
import { ObjectionHandling } from '@/components/ObjectionHandling';
import { StepInstallation } from '@/components/StepInstallation';
import { ClassShowcase } from '@/components/ClassShowcase';
import { SystemRequirements } from '@/components/SystemRequirements';
import { DownloadModal } from '@/components/DownloadModal';
import { ExitIntentModal } from '@/components/ExitIntentModal';
import { StickyCtaBar } from '@/components/StickyCtaBar';
import { Footer } from '@/components/Footer';

export default function Home() {
  const [currentLocale, setCurrentLocale] = useState<SupportedLocale>('en');
  const [theme, setTheme] = useState<'neo-dark' | 'neo-light'>('neo-dark');
  const [isDownloadModalOpen, setIsDownloadModalOpen] = useState<boolean>(false);

  // Auto-detect Geo Locale or stored preference
  useEffect(() => {
    // 1. Check URL parameters ?lang=th or ?geo=id
    const params = new URLSearchParams(window.location.search);
    const langParam = params.get('lang') || params.get('geo');
    if (langParam && ['en', 'th', 'id', 'tl'].includes(langParam)) {
      setCurrentLocale(langParam as SupportedLocale);
      return;
    }

    // 2. Check localStorage
    const saved = localStorage.getItem('ragnarok_lang') as SupportedLocale;
    if (saved && ['en', 'th', 'id', 'tl'].includes(saved)) {
      setCurrentLocale(saved);
      return;
    }

    // 3. Fallback to browser language
    const browserLang = navigator.language.toLowerCase();
    if (browserLang.startsWith('th')) setCurrentLocale('th');
    else if (browserLang.startsWith('id')) setCurrentLocale('id');
    else if (browserLang.startsWith('fil') || browserLang.startsWith('tl')) setCurrentLocale('tl');
  }, []);

  const handleLocaleChange = (locale: SupportedLocale) => {
    setCurrentLocale(locale);
    localStorage.setItem('ragnarok_lang', locale);
  };

  const handleToggleTheme = () => {
    const next = theme === 'neo-dark' ? 'neo-light' : 'neo-dark';
    setTheme(next);
    document.documentElement.setAttribute('data-theme', next);
    localStorage.setItem('ragnarok_theme', next);
  };

  const t = translations[currentLocale];

  return (
    <main className="min-h-screen relative selection:bg-amber-400 selection:text-black">
      {/* Navigation Header */}
      <Navbar
        t={t}
        currentLocale={currentLocale}
        onLocaleChange={handleLocaleChange}
        theme={theme}
        onToggleTheme={handleToggleTheme}
        onOpenDownload={() => setIsDownloadModalOpen(true)}
      />

      {/* Hero Section */}
      <HeroSection
        t={t}
        theme={theme}
        onOpenDownload={() => setIsDownloadModalOpen(true)}
      />

      {/* Direct Objection Handling (30 GB size, Steam reviews, Account) */}
      <ObjectionHandling t={t} />

      {/* Class Showcase (8 classes including Druid) */}
      <ClassShowcase
        t={t}
        onOpenDownload={() => setIsDownloadModalOpen(true)}
      />

      {/* 4-Step Installation Roadmap */}
      <StepInstallation
        t={t}
        onOpenDownload={() => setIsDownloadModalOpen(true)}
      />

      {/* Hardware System Requirements (Exact specs from prompt) */}
      <SystemRequirements t={t} />

      {/* Sticky Bottom Floating Conversion Bar */}
      <StickyCtaBar
        t={t}
        onOpenDownload={() => setIsDownloadModalOpen(true)}
      />

      {/* Download Hub Modal */}
      <DownloadModal
        isOpen={isDownloadModalOpen}
        onClose={() => setIsDownloadModalOpen(false)}
        t={t}
      />

      {/* High-Converting Exit Intent Pop-up */}
      <ExitIntentModal
        t={t}
        onClaim={() => setIsDownloadModalOpen(true)}
      />

      {/* Site Footer */}
      <Footer
        t={t}
        onOpenDownload={() => setIsDownloadModalOpen(true)}
      />
    </main>
  );
}

'use client';

import React, { useState } from 'react';
import { TranslationDict } from '@/lib/i18n';
import { Shield, Sparkles, Wand2, Crosshair, HeartPulse, Hammer, Swords, Trees } from 'lucide-react';

interface ClassShowcaseProps {
  t: TranslationDict;
  onOpenDownload: () => void;
}

interface ClassDetail {
  id: string;
  name: string;
  role: string;
  icon: any;
  desc: string;
  skills: string[];
  stats: {
    surv: number;
    dmg: number;
    mag: number;
    diff: string;
  };
  quote: string;
  color: string;
  isNew?: boolean;
}

export const ClassShowcase: React.FC<ClassShowcaseProps> = ({ t, onOpenDownload }) => {
  const [selectedClass, setSelectedClass] = useState<string>('druid');

  const classes: ClassDetail[] = [
    {
      id: 'druid',
      name: 'Druid (New Class)',
      role: 'Nature Shapeshifter • Hybrid Magic & Beast Form',
      icon: Trees,
      desc: 'Harness the ancient primordial forces of Midgard. Shapeshift into savage beast forms for ferocious melee attacks or summon roots and storms to heal allies and overwhelm foes.',
      skills: ['Wild Shapeshift', 'Thorny Entanglement', 'Wrath of the Ancient Oak'],
      stats: { surv: 85, dmg: 88, mag: 92, diff: 'Medium (60%)' },
      quote: '« The forest stirs, and Midgard remembers its wild fury. »',
      color: 'text-emerald-400 border-emerald-500/40 bg-emerald-500/10',
      isNew: true,
    },
    {
      id: 'knight',
      name: 'Lord Knight',
      role: 'Frontline Vanguard • Maximum Defense & Burst',
      icon: Shield,
      desc: 'Mounted on their mighty Peco Peco, the Lord Knight breaks through enemy lines with colossal swords and relentless resilience.',
      skills: ['Bowling Bash', 'Spiral Pierce', 'Frenzy Berserk'],
      stats: { surv: 95, dmg: 90, mag: 25, diff: 'Easy (30%)' },
      quote: '« For the honor of Prontera, no demon shall pass my shield. »',
      color: 'text-amber-400 border-amber-500/40 bg-amber-500/10',
    },
    {
      id: 'wizard',
      name: 'High Wizard',
      role: 'Elemental Sorcerer • Screen-Wiping AoE Spells',
      icon: Wand2,
      desc: 'Controls fire, water, earth, and wind to rain catastrophic storms upon legions of monsters from safe distances.',
      skills: ['Storm Gust', 'Meteor Storm', 'Lord of Vermilion'],
      stats: { surv: 40, dmg: 98, mag: 100, diff: 'Tactical (70%)' },
      quote: '« The sky obeys my voice, and frost shall freeze the abyss. »',
      color: 'text-cyan-400 border-cyan-500/40 bg-cyan-500/10',
    },
    {
      id: 'assassin',
      name: 'Assassin Cross',
      role: 'Shadow Stalker • Dual Katars & Instant Criticals',
      icon: Swords,
      desc: 'Master of lethal poisons and silent takedowns. Strikes in the blink of an eye with extreme agility and critical bursts.',
      skills: ['Sonic Blow', 'Soul Destroyer', 'Enchant Deadly Poison'],
      stats: { surv: 50, dmg: 100, mag: 30, diff: 'Expert (85%)' },
      quote: '« You will never hear the whisper of my blade in the dark. »',
      color: 'text-rose-400 border-rose-500/40 bg-rose-500/10',
    },
    {
      id: 'priest',
      name: 'High Priest',
      role: 'Divine Protector • Sacred Buffs & Resurrections',
      icon: HeartPulse,
      desc: 'The beating heart of every raid and guild war. Blesses companions, cleanses debuffs, and exorcises undead legions.',
      skills: ['Blessing & Agi Up', 'Kyrie Eleison', 'Magnus Exorcismus'],
      stats: { surv: 75, dmg: 40, mag: 95, diff: 'Friendly (40%)' },
      quote: '« Odin’s light shields all righteous souls who walk Midgard. »',
      color: 'text-blue-300 border-blue-500/40 bg-blue-500/10',
    },
    {
      id: 'sniper',
      name: 'Sniper',
      role: 'Deadeye Archer • Long-Range Precision & War Falcon',
      icon: Crosshair,
      desc: 'Companioned by a fierce battle falcon, the Sniper commands distance with piercing arrows and tactical field traps.',
      skills: ['Arrow Shower', 'Falcon Assault', 'Sharp Shooting'],
      stats: { surv: 55, dmg: 95, mag: 40, diff: 'Medium (55%)' },
      quote: '« One arrow through the tempest is all it takes to slay an MVP. »',
      color: 'text-yellow-400 border-yellow-500/40 bg-yellow-500/10',
    },
    {
      id: 'whitesmith',
      name: 'Whitesmith',
      role: 'Master Craftsman • Cart Destruction & Weapon Refinement',
      icon: Hammer,
      desc: 'Forges god-tier weapons and destroys heavy armor using their devastating reinforced merchant cart.',
      skills: ['Cart Termination', 'Maximum Over Thrust', 'Weapon Perfection'],
      stats: { surv: 80, dmg: 92, mag: 20, diff: 'Strategic (65%)' },
      quote: '« My hammer forges legends and smashes enemy defenses to dust. »',
      color: 'text-orange-400 border-orange-500/40 bg-orange-500/10',
    },
  ];

  const current = classes.find((c) => c.id === selectedClass) || classes[0];

  return (
    <section id="classes" className="py-24 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-14 space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full neo-glass border border-cyan-500/40 text-cyan-400 text-xs font-mono font-bold uppercase tracking-wider">
            <Sparkles className="w-3.5 h-3.5" />
            <span>{t.classesSection.tag}</span>
          </div>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-black font-cinzel text-white">
            {t.classesSection.title}
          </h2>
          <p className="text-gray-300 text-base">{t.classesSection.desc}</p>
        </div>

        {/* Horizontal Class Selector Tabs */}
        <div className="flex items-center justify-start lg:justify-center gap-2.5 overflow-x-auto pb-4 mb-10 scrollbar-none">
          {classes.map((cls) => {
            const Icon = cls.icon;
            const isSelected = cls.id === selectedClass;

            return (
              <button
                key={cls.id}
                onClick={() => setSelectedClass(cls.id)}
                className={`flex items-center gap-2.5 px-4 py-2.5 rounded-2xl neo-glass border font-mono text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
                  isSelected
                    ? 'border-cyan-400 shadow-neo-glow bg-cyan-500/20 text-white scale-105'
                    : 'border-white/10 text-gray-400 hover:text-white hover:border-white/30'
                }`}
              >
                <Icon className="w-4 h-4 shrink-0" />
                <span>{cls.name}</span>
                {cls.isNew && (
                  <span className="px-1.5 py-0.5 rounded text-[9px] bg-emerald-500 text-black font-bold uppercase">
                    New
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Selected Class Showcase Panel */}
        <div className="max-w-4xl mx-auto p-8 sm:p-10 rounded-3xl neo-glass border border-white/15 text-left grid grid-cols-1 md:grid-cols-12 gap-8 items-center shadow-2xl">
          {/* Left Info Column */}
          <div className="md:col-span-7 space-y-6">
            <div className="space-y-2">
              <div className="inline-flex items-center gap-2 text-xs font-mono font-bold uppercase text-cyan-400">
                <span>{current.role}</span>
              </div>
              <h3 className="text-2xl sm:text-3xl font-black font-cinzel text-white">
                {current.name}
              </h3>
            </div>

            <p className="text-sm text-gray-300 leading-relaxed font-light">{current.desc}</p>

            {/* Stat Bars */}
            <div className="space-y-3 font-mono text-xs">
              <div>
                <div className="flex justify-between text-gray-400 mb-1">
                  <span>Survivability / Armor:</span>
                  <strong className="text-white">{current.stats.surv}%</strong>
                </div>
                <div className="w-full h-2 rounded-full bg-white/10 overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-cyan-400 to-blue-500 rounded-full transition-all duration-500"
                    style={{ width: `${current.stats.surv}%` }}
                  />
                </div>
              </div>

              <div>
                <div className="flex justify-between text-gray-400 mb-1">
                  <span>Damage Output:</span>
                  <strong className="text-white">{current.stats.dmg}%</strong>
                </div>
                <div className="w-full h-2 rounded-full bg-white/10 overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-amber-400 to-yellow-500 rounded-full transition-all duration-500"
                    style={{ width: `${current.stats.dmg}%` }}
                  />
                </div>
              </div>

              <div>
                <div className="flex justify-between text-gray-400 mb-1">
                  <span>Magic & Elements:</span>
                  <strong className="text-white">{current.stats.mag}%</strong>
                </div>
                <div className="w-full h-2 rounded-full bg-white/10 overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-purple-400 to-pink-500 rounded-full transition-all duration-500"
                    style={{ width: `${current.stats.mag}%` }}
                  />
                </div>
              </div>
            </div>

            {/* Skills */}
            <div className="pt-2 flex flex-wrap gap-2">
              {current.skills.map((skill, i) => (
                <span
                  key={i}
                  className="px-3 py-1 rounded-full bg-white/5 border border-white/10 text-xs font-mono text-gray-300"
                >
                  ⚡ {skill}
                </span>
              ))}
            </div>

            {/* CTA */}
            <div className="pt-4">
              <button
                onClick={onOpenDownload}
                className="btn-cyber-glow px-6 py-3 rounded-xl bg-gradient-to-r from-amber-400 to-yellow-500 text-black font-bold text-xs uppercase tracking-wider shadow-gold-glow hover:scale-105 transition-all cursor-pointer"
              >
                {t.classesSection.ctaClass}: {current.name}
              </button>
            </div>
          </div>

          {/* Right Visual Crest Column */}
          <div className="md:col-span-5 flex flex-col items-center justify-center text-center space-y-4">
            <div className="w-40 h-40 rounded-full neo-glass border-2 border-amber-400/40 flex items-center justify-center shadow-gold-glow animate-pulse-glow">
              {React.createElement(current.icon, {
                className: 'w-20 h-20 text-amber-400',
              })}
            </div>

            <div className="p-4 rounded-2xl bg-black/40 border-l-2 border-amber-400 max-w-xs text-xs italic text-gray-300 font-cinzel">
              {current.quote}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

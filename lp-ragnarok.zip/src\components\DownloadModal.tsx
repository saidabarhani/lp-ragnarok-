'use client';

import React, { useState } from 'react';
import { TranslationDict } from '@/lib/i18n';
import { X, Download, ShieldCheck, ExternalLink, Smartphone, Check } from 'lucide-react';

interface DownloadModalProps {
  isOpen: boolean;
  onClose: () => void;
  t: TranslationDict;
}

export const DownloadModal: React.FC<DownloadModalProps> = ({ isOpen, onClose, t }) => {
  const [downloadStarted, setDownloadStarted] = useState<boolean>(false);
  const [progress, setProgress] = useState<number>(0);

  if (!isOpen) return null;

  const handleSimulateDownload = () => {
    setDownloadStarted(true);
    let p = 0;
    const interval = setInterval(() => {
      p += Math.floor(Math.random() * 12) + 8;
      if (p >= 100) {
        p = 100;
        clearInterval(interval);
      }
      setProgress(p);
    }, 150);
  };

  return (
    <div
      className="fixed inset-0 z-[120] flex items-center justify-center p-4 bg-black/85 backdrop-blur-xl animate-fade-in"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-2xl p-7 sm:p-9 rounded-3xl neo-glass border border-cyan-500/40 shadow-2xl text-left space-y-6"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-full bg-white/10 text-gray-400 hover:text-white hover:bg-white/20 transition-all cursor-pointer"
          aria-label="Close modal"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="space-y-1.5">
          <div className="inline-flex items-center gap-2 text-xs font-mono font-bold text-cyan-400 uppercase">
            <ShieldCheck className="w-4 h-4" />
            <span>Official Gravity Launcher</span>
          </div>
          <h3 className="text-2xl sm:text-3xl font-black font-cinzel text-white">
            {t.downloadModal.title}
          </h3>
          <p className="text-sm text-gray-300 font-light">{t.downloadModal.subtitle}</p>
        </div>

        {/* Official Store Direct Routing Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {/* Steam Official Link */}
          <a
            href="https://store.steampowered.com/app/4212480/Ragnarok_The_New_World/"
            target="_blank"
            rel="noopener noreferrer"
            className="p-5 rounded-2xl neo-glass border border-cyan-500/40 hover:border-cyan-300 hover:bg-cyan-500/10 transition-all flex items-center justify-between group"
          >
            <div className="space-y-1 text-left">
              <span className="text-[10px] font-mono uppercase text-cyan-300 tracking-wider">
                PC & Steam Deck
              </span>
              <div className="font-bold text-white text-base font-cinzel flex items-center gap-1.5">
                <span>Play on Steam</span>
                <ExternalLink className="w-3.5 h-3.5 opacity-60 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
              </div>
              <div className="text-[11px] text-gray-400">Official Store Page</div>
            </div>
            <div className="w-10 h-10 rounded-xl bg-cyan-500/20 text-cyan-300 flex items-center justify-center font-bold">
              PC
            </div>
          </a>

          {/* Google Play Official Link */}
          <a
            href="https://play.google.com/store/apps/details?id=com.ggv.roworldsea.aos&hl=en_US"
            target="_blank"
            rel="noopener noreferrer"
            className="p-5 rounded-2xl neo-glass border border-amber-500/40 hover:border-amber-300 hover:bg-amber-500/10 transition-all flex items-center justify-between group"
          >
            <div className="space-y-1 text-left">
              <span className="text-[10px] font-mono uppercase text-amber-300 tracking-wider">
                Mobile & Tablet
              </span>
              <div className="font-bold text-white text-base font-cinzel flex items-center gap-1.5">
                <span>Google Play</span>
                <ExternalLink className="w-3.5 h-3.5 opacity-60 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
              </div>
              <div className="text-[11px] text-gray-400">Android Official App</div>
            </div>
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-300 flex items-center justify-center font-bold">
              <Smartphone className="w-5 h-5" />
            </div>
          </a>
        </div>

        {/* Direct Windows Client Setup Simulator */}
        <div className="p-5 rounded-2xl bg-black/40 border border-white/10 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3 text-xs font-mono">
            <div>
              <strong className="text-white block">Ragnarok_The_New_World_Setup_2026.exe</strong>
              <span className="text-gray-400">Direct Installer • SHA-256 Verified • 30 GB World</span>
            </div>

            <button
              onClick={handleSimulateDownload}
              disabled={downloadStarted}
              className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-400 to-yellow-500 text-black font-bold text-xs uppercase tracking-wider flex items-center gap-2 hover:opacity-95 transition-all cursor-pointer disabled:opacity-50"
            >
              {downloadStarted && progress < 100 ? (
                <>
                  <span className="loading loading-spinner loading-xs"></span>
                  <span>Downloading... {progress}%</span>
                </>
              ) : progress === 100 ? (
                <>
                  <Check className="w-3.5 h-3.5 text-black" />
                  <span>Download Complete</span>
                </>
              ) : (
                <>
                  <Download className="w-3.5 h-3.5" />
                  <span>Direct Download</span>
                </>
              )}
            </button>
          </div>

          {downloadStarted && (
            <div className="space-y-1.5 pt-2 border-t border-white/10">
              <div className="w-full h-2 rounded-full bg-white/10 overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-cyan-400 to-amber-400 rounded-full transition-all duration-200"
                  style={{ width: `${progress}%` }}
                />
              </div>
              <div className="flex justify-between text-[10px] text-gray-400 font-mono">
                <span>Speed: 84.5 MB/s</span>
                <span>
                  {progress < 100 ? `Estimated: ~${Math.max(1, Math.round((100 - progress) / 10))}s` : 'Ready to Install'}
                </span>
              </div>
            </div>
          )}
        </div>

        {/* Specs Reminder Note */}
        <div className="text-xs text-gray-400 font-mono flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{t.downloadModal.pcSpecsNote}</span>
        </div>
      </div>
    </div>
  );
};

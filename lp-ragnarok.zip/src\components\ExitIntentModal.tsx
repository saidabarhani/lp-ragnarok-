'use client';

import React, { useEffect, useState } from 'react';
import { TranslationDict } from '@/lib/i18n';
import { Gift, X, Sparkles, Check, ArrowRight } from 'lucide-react';

interface ExitIntentModalProps {
  t: TranslationDict;
  onClaim: () => void;
}

export const ExitIntentModal: React.FC<ExitIntentModalProps> = ({ t, onClaim }) => {
  const [isVisible, setIsVisible] = useState<boolean>(false);
  const [hasTriggered, setHasTriggered] = useState<boolean>(false);
  const [copiedCode, setCopiedCode] = useState<boolean>(false);

  useEffect(() => {
    // Check if dismissed before in session
    const dismissed = sessionStorage.getItem('exit_popup_dismissed');
    if (dismissed) return;

    const handleMouseLeave = (e: MouseEvent) => {
      if (e.clientY <= 20 && !hasTriggered) {
        setIsVisible(true);
        setHasTriggered(true);
      }
    };

    // Timer fallback trigger after 40 seconds
    const timer = setTimeout(() => {
      if (!hasTriggered && !sessionStorage.getItem('exit_popup_dismissed')) {
        setIsVisible(true);
        setHasTriggered(true);
      }
    }, 40000);

    document.addEventListener('mouseleave', handleMouseLeave);

    return () => {
      document.removeEventListener('mouseleave', handleMouseLeave);
      clearTimeout(timer);
    };
  }, [hasTriggered]);

  const handleClose = () => {
    setIsVisible(false);
    sessionStorage.setItem('exit_popup_dismissed', 'true');
  };

  const handleCopyCode = () => {
    navigator.clipboard.writeText('MIDGARD-2060-LAUNCH');
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  if (!isVisible) return null;

  return (
    <div
      className="fixed inset-0 z-[130] flex items-center justify-center p-4 bg-black/90 backdrop-blur-2xl animate-fade-in"
      onClick={handleClose}
    >
      <div
        className="relative w-full max-w-lg p-8 rounded-3xl neo-glass border-2 border-amber-400 shadow-gold-glow text-center space-y-6 bg-gradient-to-b from-gray-950 via-gray-900 to-black"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={handleClose}
          className="absolute top-4 right-4 p-2 rounded-full bg-white/10 text-gray-400 hover:text-white transition-all cursor-pointer"
          aria-label="Close"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Badge */}
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/20 text-amber-400 text-xs font-mono font-bold uppercase tracking-wider border border-amber-500/40">
          <Sparkles className="w-3.5 h-3.5" />
          <span>{t.exitPopup.badge}</span>
        </div>

        {/* Title & Desc */}
        <div className="space-y-2">
          <h3 className="text-2xl sm:text-3xl font-black font-cinzel text-white leading-tight">
            {t.exitPopup.title}
          </h3>
          <p className="text-sm text-gray-300 font-light leading-relaxed">{t.exitPopup.desc}</p>
        </div>

        {/* Voucher Code Card */}
        <div className="p-4 rounded-2xl bg-white/5 border border-amber-400/30 flex items-center justify-between gap-3">
          <div className="text-left font-mono">
            <span className="text-[10px] text-gray-400 uppercase tracking-widest block">
              Redemption Promo Code
            </span>
            <strong className="text-amber-400 text-base sm:text-lg tracking-wider">
              MIDGARD-2060-LAUNCH
            </strong>
          </div>
          <button
            onClick={handleCopyCode}
            className="px-3 py-1.5 rounded-lg bg-amber-400 text-black text-xs font-bold font-mono hover:bg-amber-300 transition-colors"
          >
            {copiedCode ? <Check className="w-4 h-4" /> : 'Copy'}
          </button>
        </div>

        {/* Actions */}
        <div className="space-y-3 pt-2">
          <button
            onClick={() => {
              handleClose();
              onClaim();
            }}
            className="btn-cyber-glow w-full py-4 rounded-2xl bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 text-black font-black text-sm uppercase tracking-wider shadow-gold-glow hover:scale-[1.02] active:scale-[0.98] transition-all cursor-pointer flex items-center justify-center gap-2"
          >
            <Gift className="w-4 h-4" />
            <span>{t.exitPopup.claimBtn}</span>
            <ArrowRight className="w-4 h-4" />
          </button>

          <button
            onClick={handleClose}
            className="text-xs text-gray-400 hover:text-gray-300 transition-colors cursor-pointer"
          >
            {t.exitPopup.noThanks}
          </button>
        </div>
      </div>
    </div>
  );
};

'use client';

import React from 'react';
import { TranslationDict } from '@/lib/i18n';
import { Shield, ExternalLink } from 'lucide-react';

interface FooterProps {
  t: TranslationDict;
  onOpenDownload: () => void;
}

export const Footer: React.FC<FooterProps> = ({ t, onOpenDownload }) => {
  return (
    <footer className="border-t border-white/10 bg-black/80 py-16 text-left relative z-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-10 mb-12">
          {/* Brand Info */}
          <div className="md:col-span-2 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-500/20 to-cyan-500/20 border border-amber-400/40 flex items-center justify-center text-amber-400">
                <Shield className="w-5 h-5" />
              </div>
              <div>
                <div className="font-black font-cinzel text-lg tracking-widest text-white">
                  RAGNAROK: THE NEW WORLD
                </div>
                <div className="text-xs font-mono text-cyan-400">GRAVITY GAME VISION OFFICIAL</div>
              </div>
            </div>
            <p className="text-sm text-gray-400 max-w-md font-light leading-relaxed">
              Step into the reimagined universe of Midgard. Free-to-play open-world MMORPG with complete cross-play across PC and Mobile.
            </p>
          </div>

          {/* Official Stores */}
          <div className="space-y-3 font-mono text-xs">
            <h4 className="text-white font-bold uppercase tracking-wider font-cinzel text-sm">
              Official Stores
            </h4>
            <ul className="space-y-2 text-gray-400">
              <li>
                <a
                  href="https://store.steampowered.com/app/4212480/Ragnarok_The_New_World/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-cyan-400 transition-colors flex items-center gap-1.5"
                >
                  <span>Steam PC Store Page</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </li>
              <li>
                <a
                  href="https://play.google.com/store/apps/details?id=com.ggv.roworldsea.aos&hl=en_US"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-amber-400 transition-colors flex items-center gap-1.5"
                >
                  <span>Google Play (Android)</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </li>
              <li>
                <button
                  onClick={onOpenDownload}
                  className="hover:text-white transition-colors cursor-pointer text-left"
                >
                  Direct Windows Launcher
                </button>
              </li>
            </ul>
          </div>

          {/* GEO Support */}
          <div className="space-y-3 font-mono text-xs">
            <h4 className="text-white font-bold uppercase tracking-wider font-cinzel text-sm">
              Target GEO Servers
            </h4>
            <div className="space-y-1.5 text-gray-400">
              <div>🇹🇭 Thailand (SEA-TH-01) — 18ms</div>
              <div>🇮🇩 Indonesia (SEA-ID-01) — 24ms</div>
              <div>🇵🇭 Philippines (SEA-PH-01) — 28ms</div>
              <div>🇺🇸 United States (NA-US-East) — 32ms</div>
            </div>
          </div>
        </div>

        <div className="pt-8 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs font-mono text-gray-500">
          <div>
            © 2026 Gravity Game Vision Inc. & Ragnarok: The New World. All rights reserved.
          </div>
          <div className="flex items-center gap-4">
            <span className="text-gray-400">Privacy Policy</span>
            <span>•</span>
            <span className="text-gray-400">Terms of Service</span>
            <span>•</span>
            <span className="text-gray-400">Support 24/7</span>
          </div>
        </div>
      </div>
    </footer>
  );
};

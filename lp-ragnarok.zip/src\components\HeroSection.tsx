'use client';

import React, { useState } from 'react';
import { TranslationDict } from '@/lib/i18n';
import { ThreeScene } from './ThreeScene';
import {
  Download,
  Flame,
  Gamepad2,
  Shield,
  Sparkles,
  Users,
  Compass,
  ArrowRight,
  Gift,
  CheckCircle2,
} from 'lucide-react';

interface HeroSectionProps {
  t: TranslationDict;
  theme: 'neo-dark' | 'neo-light';
  onOpenDownload: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({ t, theme, onOpenDownload }) => {
  const [playerName, setPlayerName] = useState<string>('Aventurier');
  const [isEditingName, setIsEditingName] = useState<boolean>(false);

  return (
    <section className="relative pt-28 pb-20 overflow-hidden">
      {/* 2060 Cyber Background Ambient Glows */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[700px] h-[700px] bg-cyan-500/10 rounded-full blur-[140px] pointer-events-none -z-10" />
      <div className="absolute top-10 right-10 w-[450px] h-[450px] bg-amber-500/10 rounded-full blur-[120px] pointer-events-none -z-10" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Top Server & Live Event Status Bar */}
        <div className="flex flex-wrap items-center justify-between gap-3 mb-8 p-3 neo-glass rounded-2xl border border-white/10 text-xs">
          <div className="flex items-center gap-2.5">
            <span className="relative flex h-2.5 w-2.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
            </span>
            <span className="text-gray-300 font-mono">
              SERVER <strong className="text-emerald-400">MIDGARD-PRIME 2060</strong> : ONLINE
            </span>
            <span className="text-gray-600">|</span>
            <span className="text-cyan-400 font-mono">⚡ 24 ms</span>
            <span className="text-gray-600 hidden sm:inline">|</span>
            <span className="text-gray-300 font-mono hidden sm:inline">
              👥 <strong>14,892</strong> Concurrent Adventurers
            </span>
          </div>

          <div className="flex items-center gap-2 text-amber-400 font-mono font-medium">
            <Flame className="w-3.5 h-3.5 text-amber-500 animate-pulse" />
            <span>SPECIAL LAUNCH: +200% EXP & DROP EVENT ACTIVE</span>
          </div>
        </div>

        {/* Hero Main Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          {/* Left Column: Core Message & Conversion Anchors */}
          <div className="lg:col-span-7 space-y-6 text-left">
            {/* Official Badge */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full neo-glass border border-cyan-500/40 text-cyan-300 text-xs font-mono font-semibold tracking-wider uppercase">
              <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
              <span>{t.hero.badge}</span>
            </div>

            {/* Personalized Greeting (Prompt requirement: Bonjour [Nom]) */}
            <div className="flex items-center gap-2 text-sm text-gray-300 font-mono">
              <span>{t.hero.greeting.split(',')[0]},</span>
              {isEditingName ? (
                <input
                  type="text"
                  value={playerName}
                  onChange={(e) => setPlayerName(e.target.value)}
                  onBlur={() => setIsEditingName(false)}
                  onKeyDown={(e) => e.key === 'Enter' && setIsEditingName(false)}
                  autoFocus
                  className="bg-black/60 border border-cyan-400 text-cyan-300 px-2 py-0.5 rounded text-sm font-bold w-36 outline-none"
                />
              ) : (
                <button
                  onClick={() => setIsEditingName(true)}
                  className="text-amber-400 font-bold underline decoration-dotted hover:text-amber-300 transition-colors"
                  title="Click to customize your adventurer name"
                >
                  [{playerName}] ✏️
                </button>
              )}
              <span>{t.hero.greeting.split(',')[1] || ''}</span>
            </div>

            {/* Main Headline */}
            <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-black font-cinzel leading-[1.15] tracking-tight">
              {t.hero.title1}{' '}
              <span className="text-gradient-cyan block sm:inline">
                {t.hero.titleHighlight}
              </span>{' '}
              {t.hero.title2}
            </h1>

            {/* Pitch Text from PDF & Prompt */}
            <p className="text-base sm:text-lg text-gray-300 leading-relaxed font-light">
              {t.hero.description}
            </p>

            {/* Conversion CTA Button Cluster */}
            <div className="pt-2 flex flex-col sm:flex-row items-stretch sm:items-center gap-4">
              <button
                onClick={onOpenDownload}
                className="btn-cyber-glow group flex items-center justify-center gap-3 px-8 py-4 rounded-2xl bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 text-black font-black text-base tracking-wide shadow-gold-glow hover:scale-[1.02] active:scale-[0.98] transition-all cursor-pointer"
              >
                <Download className="w-5 h-5 text-black group-hover:translate-y-0.5 transition-transform" />
                <span>{t.hero.ctaPrimary}</span>
              </button>

              <a
                href="#installation"
                className="flex items-center justify-center gap-2 px-6 py-4 rounded-2xl neo-glass text-white font-semibold text-sm hover:border-cyan-400/60 hover:text-cyan-300 transition-all"
              >
                <Compass className="w-4 h-4 text-cyan-400" />
                <span>{t.hero.ctaSecondary}</span>
                <ArrowRight className="w-4 h-4 opacity-70 group-hover:translate-x-1 transition-transform" />
              </a>
            </div>

            <div className="text-xs text-gray-400 font-mono flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>{t.hero.ctaMeta}</span>
            </div>

            {/* Free Starter Gift Banner */}
            <div className="p-4 rounded-2xl neo-glass border border-amber-500/30 bg-amber-500/5 flex items-start gap-3.5">
              <div className="p-2 rounded-xl bg-amber-500/20 text-amber-400 shrink-0">
                <Gift className="w-5 h-5" />
              </div>
              <div className="text-xs space-y-1">
                <div className="font-bold text-amber-300">{t.hero.starterGiftTitle}</div>
                <div className="text-gray-300 leading-relaxed">{t.hero.starterGiftDesc}</div>
              </div>
            </div>

            {/* Metrics Trust Strip */}
            <div className="grid grid-cols-3 gap-4 pt-4 border-t border-white/10 font-mono">
              <div>
                <div className="text-2xl font-black font-cinzel text-white">25M+</div>
                <div className="text-[11px] text-gray-400 uppercase">{t.hero.statsPlayers}</div>
              </div>
              <div>
                <div className="text-2xl font-black font-cinzel text-amber-400">4.9 ★</div>
                <div className="text-[11px] text-gray-400 uppercase">{t.hero.statsRating}</div>
              </div>
              <div>
                <div className="text-2xl font-black font-cinzel text-cyan-400">8 Classes</div>
                <div className="text-[11px] text-gray-400 uppercase">{t.hero.statsClasses}</div>
              </div>
            </div>
          </div>

          {/* Right Column: 3D Holographic Scene & Floating Futuristic Badges */}
          <div className="lg:col-span-5 relative min-h-[460px] flex items-center justify-center">
            {/* The Three.js Canvas */}
            <ThreeScene theme={theme} />

            {/* Layered Cyberpunk HUD Elements */}
            <div className="absolute top-4 left-4 p-3.5 rounded-2xl neo-glass border border-cyan-500/30 text-left space-y-1 shadow-neo-glow animate-float-slow">
              <div className="text-[10px] font-mono text-cyan-400 uppercase tracking-widest flex items-center gap-1.5">
                <Shield className="w-3 h-3 text-cyan-400" /> Cross-Platform 2060
              </div>
              <div className="text-xs font-bold text-white">PC Steam ⇄ Mobile Sync</div>
              <div className="text-[10px] text-gray-400">Zero progress lost on transition</div>
            </div>

            <div className="absolute bottom-6 right-4 p-3.5 rounded-2xl neo-glass border border-amber-500/30 text-left space-y-1 shadow-gold-glow animate-float-slow [animation-delay:1.5s]">
              <div className="text-[10px] font-mono text-amber-400 uppercase tracking-widest flex items-center gap-1.5">
                <Gamepad2 className="w-3 h-3 text-amber-400" /> New Class Revealed
              </div>
              <div className="text-xs font-bold text-white">The Druid Shape-Shifter</div>
              <div className="text-[10px] text-gray-400">Nature magic & savage beasts</div>
            </div>

            <div className="absolute top-1/2 right-0 translate-x-2 -translate-y-1/2 p-3 rounded-2xl neo-glass border border-purple-500/30 text-left space-y-1 hidden sm:block">
              <div className="text-[10px] font-mono text-purple-400 flex items-center gap-1">
                <Users className="w-3 h-3" /> War of Emperium
              </div>
              <div className="text-xs font-bold text-white">Weekly 100v100 Sieges</div>
            </div>
          </div>
        </div>

        {/* 3 Message Angles Carousel/Grid (Directly from PDF Section 5) */}
        <div className="mt-20 pt-10 border-t border-white/10">
          <div className="text-center max-w-2xl mx-auto mb-8 space-y-2">
            <span className="text-xs font-mono font-bold tracking-widest text-cyan-400 uppercase">
              // CORE CAMPAIGN ANGLES
            </span>
            <h2 className="text-2xl font-bold font-cinzel text-white">
              Why Adventurers Are Choosing The New World
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Angle A: Return to Midgard */}
            <div className="p-6 rounded-2xl neo-glass border border-cyan-500/20 hover:border-cyan-400 transition-all space-y-3 text-left">
              <div className="w-10 h-10 rounded-xl bg-cyan-500/20 text-cyan-300 flex items-center justify-center font-bold font-cinzel">
                A
              </div>
              <h3 className="text-lg font-bold text-white">{t.angles.angleATitle}</h3>
              <p className="text-sm text-gray-300 leading-relaxed font-light">
                {t.angles.angleADesc}
              </p>
            </div>

            {/* Angle B: Freedom in Gameplay */}
            <div className="p-6 rounded-2xl neo-glass border border-amber-500/20 hover:border-amber-400 transition-all space-y-3 text-left">
              <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-300 flex items-center justify-center font-bold font-cinzel">
                B
              </div>
              <h3 className="text-lg font-bold text-white">{t.angles.angleBTitle}</h3>
              <p className="text-sm text-gray-300 leading-relaxed font-light">
                {t.angles.angleBDesc}
              </p>
            </div>

            {/* Angle C: World with Friends */}
            <div className="p-6 rounded-2xl neo-glass border border-purple-500/20 hover:border-purple-400 transition-all space-y-3 text-left">
              <div className="w-10 h-10 rounded-xl bg-purple-500/20 text-purple-300 flex items-center justify-center font-bold font-cinzel">
                C
              </div>
              <h3 className="text-lg font-bold text-white">{t.angles.angleCTitle}</h3>
              <p className="text-sm text-gray-300 leading-relaxed font-light">
                {t.angles.angleCDesc}
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

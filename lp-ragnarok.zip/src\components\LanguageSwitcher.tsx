'use client';

import React from 'react';
import { SupportedLocale } from '@/lib/i18n';
import { Globe, Check } from 'lucide-react';

interface LanguageSwitcherProps {
  currentLocale: SupportedLocale;
  onLocaleChange: (locale: SupportedLocale) => void;
}

const languages: { code: SupportedLocale; label: string; flag: string; country: string }[] = [
  { code: 'en', label: 'English', flag: '🇺🇸', country: 'United States' },
  { code: 'th', label: 'ไทย (Thai)', flag: '🇹🇭', country: 'Thailand' },
  { code: 'id', label: 'Bahasa Indonesia', flag: '🇮🇩', country: 'Indonesia' },
  { code: 'tl', label: 'Tagalog / Filipino', flag: '🇵🇭', country: 'Philippines' },
];

export const LanguageSwitcher: React.FC<LanguageSwitcherProps> = ({
  currentLocale,
  onLocaleChange,
}) => {
  const currentLang = languages.find((l) => l.code === currentLocale) || languages[0];

  return (
    <div className="dropdown dropdown-end">
      <label
        tabIndex={0}
        className="btn btn-sm btn-ghost neo-glass border border-white/10 hover:border-cyan-400 gap-2 normal-case text-xs font-semibold px-3 py-1 rounded-full cursor-pointer flex items-center"
        aria-label="Select Country & Language"
      >
        <span className="text-base">{currentLang.flag}</span>
        <span className="hidden sm:inline font-mono tracking-wider">{currentLang.label}</span>
        <Globe className="w-3.5 h-3.5 text-cyan-400 opacity-80" />
      </label>
      <ul
        tabIndex={0}
        className="dropdown-content z-[100] menu p-2 shadow-2xl neo-glass rounded-2xl w-56 mt-2 border border-cyan-500/30 text-xs backdrop-blur-xl bg-gray-950/95"
      >
        <li className="menu-title text-[10px] uppercase tracking-widest text-cyan-400/80 px-2 py-1 font-bold">
          Target GEO Regions
        </li>
        {languages.map((lang) => {
          const isActive = lang.code === currentLocale;
          return (
            <li key={lang.code}>
              <button
                onClick={() => onLocaleChange(lang.code)}
                className={`flex items-center justify-between py-2 px-3 rounded-xl transition-all ${
                  isActive
                    ? 'bg-cyan-500/20 text-cyan-300 font-bold border border-cyan-500/40'
                    : 'hover:bg-white/5 text-gray-300'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <span className="text-lg">{lang.flag}</span>
                  <div className="text-left">
                    <div className="font-medium text-white">{lang.label}</div>
                    <div className="text-[10px] text-gray-400">{lang.country}</div>
                  </div>
                </div>
                {isActive && <Check className="w-3.5 h-3.5 text-cyan-400" />}
              </button>
            </li>
          );
        })}
      </ul>
    </div>
  );
};

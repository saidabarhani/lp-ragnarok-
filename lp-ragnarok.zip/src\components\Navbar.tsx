'use client';

import React from 'react';
import { SupportedLocale, TranslationDict } from '@/lib/i18n';
import { LanguageSwitcher } from './LanguageSwitcher';
import { ThemeSwitcher } from './ThemeSwitcher';
import { Shield, Download, Sparkles } from 'lucide-react';

interface NavbarProps {
  t: TranslationDict;
  currentLocale: SupportedLocale;
  onLocaleChange: (loc: SupportedLocale) => void;
  theme: 'neo-dark' | 'neo-light';
  onToggleTheme: () => void;
  onOpenDownload: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  t,
  currentLocale,
  onLocaleChange,
  theme,
  onToggleTheme,
  onOpenDownload,
}) => {
  return (
    <header className="fixed top-0 left-0 right-0 z-50 neo-glass border-b border-white/10 backdrop-blur-2xl">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between gap-4">
        {/* Brand Logo */}
        <a href="#" className="flex items-center gap-3 group">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-500/20 to-cyan-500/20 border border-amber-400/40 flex items-center justify-center text-amber-400 shadow-gold-glow group-hover:scale-105 transition-transform">
            <Shield className="w-5 h-5" />
          </div>
          <div className="text-left">
            <div className="font-black font-cinzel text-base tracking-widest text-white leading-none">
              RAGNAROK
            </div>
            <div className="text-[10px] font-mono text-cyan-400 tracking-wider font-semibold">
              THE NEW WORLD 2060
            </div>
          </div>
        </a>

        {/* Nav Links (Desktop) */}
        <nav className="hidden lg:flex items-center gap-6 font-mono text-xs uppercase tracking-wider text-gray-300">
          <a href="#hero" className="hover:text-cyan-400 transition-colors">
            {t.nav.world}
          </a>
          <a href="#classes" className="hover:text-cyan-400 transition-colors">
            {t.nav.classes}
          </a>
          <a href="#installation" className="hover:text-amber-400 text-amber-300 transition-colors flex items-center gap-1 font-bold">
            <Sparkles className="w-3.5 h-3.5" />
            <span>{t.nav.install}</span>
          </a>
          <a href="#requirements" className="hover:text-cyan-400 transition-colors">
            {t.nav.requirements}
          </a>
        </nav>

        {/* Right Controls: Language, Theme & Primary CTA */}
        <div className="flex items-center gap-3">
          <LanguageSwitcher currentLocale={currentLocale} onLocaleChange={onLocaleChange} />
          <ThemeSwitcher theme={theme} onToggleTheme={onToggleTheme} />

          <button
            onClick={onOpenDownload}
            className="btn-cyber-glow hidden sm:flex items-center gap-2 px-5 py-2.5 rounded-full bg-gradient-to-r from-amber-400 to-yellow-500 text-black font-bold font-mono text-xs uppercase tracking-wider shadow-gold-glow hover:scale-105 active:scale-95 transition-all cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>{t.nav.playNow}</span>
          </button>
        </div>
      </div>
    </header>
  );
};

'use client';

import React, { useState } from 'react';
import { TranslationDict } from '@/lib/i18n';
import { HardDrive, MessageSquareQuote, ShieldCheck, Zap, HelpCircle } from 'lucide-react';

interface ObjectionHandlingProps {
  t: TranslationDict;
}

export const ObjectionHandling: React.FC<ObjectionHandlingProps> = ({ t }) => {
  const [speedMbps, setSpeedMbps] = useState<number>(200);

  // 30 GB in Megabits = 30 * 1024 * 8 = 245,760 Mbits
  const downloadMinutes = Math.max(1, Math.round(245760 / speedMbps / 60));

  return (
    <section className="py-20 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-14 space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full neo-glass border border-cyan-500/40 text-cyan-400 text-xs font-mono font-bold tracking-wider">
            <HelpCircle className="w-3.5 h-3.5" />
            <span>{t.objections.tag}</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold font-cinzel text-white">
            {t.objections.title}
          </h2>
          <p className="text-gray-300 text-base">{t.objections.desc}</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Card 1: 30 GB Storage Transparency */}
          <div className="p-7 rounded-3xl neo-glass border border-white/10 hover:border-cyan-400/50 transition-all flex flex-col justify-between space-y-6">
            <div className="space-y-4 text-left">
              <div className="w-12 h-12 rounded-2xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
                <HardDrive className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold text-white">{t.objections.storageTitle}</h3>
              <p className="text-sm text-gray-300 leading-relaxed font-light">
                {t.objections.storageDesc}
              </p>
            </div>

            {/* Interactive Download Time Estimator */}
            <div className="pt-4 border-t border-white/10 space-y-3 text-left">
              <div className="text-xs font-mono text-cyan-300 flex justify-between">
                <span>Your Internet Speed:</span>
                <strong>{speedMbps} Mbps</strong>
              </div>
              <input
                type="range"
                min="50"
                max="1000"
                step="50"
                value={speedMbps}
                onChange={(e) => setSpeedMbps(Number(e.target.value))}
                className="range range-xs range-info"
              />
              <div className="text-xs text-gray-300 flex items-center justify-between font-mono">
                <span>Estimated Download Time:</span>
                <span className="text-amber-400 font-bold">~{downloadMinutes} mins</span>
              </div>
            </div>
          </div>

          {/* Card 2: Addressing Steam Reviews */}
          <div className="p-7 rounded-3xl neo-glass border border-white/10 hover:border-amber-400/50 transition-all flex flex-col justify-between space-y-6">
            <div className="space-y-4 text-left">
              <div className="w-12 h-12 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
                <MessageSquareQuote className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold text-white">{t.objections.reviewsTitle}</h3>
              <p className="text-sm text-gray-300 leading-relaxed font-light">
                {t.objections.reviewsDesc}
              </p>
            </div>

            <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10 text-xs text-gray-300 text-left font-mono space-y-1">
              <div className="text-amber-400 font-bold flex items-center gap-1.5">
                <Zap className="w-3.5 h-3.5" /> Latest Patch 2026.4
              </div>
              <div>• Server latency reduced by 48% across SEA & NA</div>
              <div>• Seamless Steam login integration active</div>
            </div>
          </div>

          {/* Card 3: Account Creation & First Login */}
          <div className="p-7 rounded-3xl neo-glass border border-white/10 hover:border-purple-400/50 transition-all flex flex-col justify-between space-y-6">
            <div className="space-y-4 text-left">
              <div className="w-12 h-12 rounded-2xl bg-purple-500/10 border border-purple-500/30 flex items-center justify-center text-purple-400">
                <ShieldCheck className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold text-white">{t.objections.accountTitle}</h3>
              <p className="text-sm text-gray-300 leading-relaxed font-light">
                {t.objections.accountDesc}
              </p>
            </div>

            <div className="p-3.5 rounded-2xl bg-purple-500/10 border border-purple-500/20 text-xs text-purple-300 text-left font-mono">
              <strong>Zero Friction Guarantee:</strong> Sign in with your existing Steam ID, Google, or Apple ID in under 15 seconds.
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

'use client';

import React, { useState } from 'react';
import { TranslationDict } from '@/lib/i18n';
import { Download, MonitorCheck, UserPlus, PlayCircle, CheckCircle, ArrowRight } from 'lucide-react';

interface StepInstallationProps {
  t: TranslationDict;
  onOpenDownload: () => void;
}

export const StepInstallation: React.FC<StepInstallationProps> = ({ t, onOpenDownload }) => {
  const [activeStep, setActiveStep] = useState<number>(1);

  const stepsData = [
    {
      num: 1,
      title: t.steps.step1Title,
      desc: t.steps.step1Desc,
      action: t.steps.step1Action,
      icon: Download,
      color: 'text-cyan-400',
      bgColor: 'bg-cyan-500/10 border-cyan-500/30',
    },
    {
      num: 2,
      title: t.steps.step2Title,
      desc: t.steps.step2Desc,
      action: t.steps.step2Action,
      icon: MonitorCheck,
      color: 'text-amber-400',
      bgColor: 'bg-amber-500/10 border-amber-500/30',
    },
    {
      num: 3,
      title: t.steps.step3Title,
      desc: t.steps.step3Desc,
      action: t.steps.step3Action,
      icon: UserPlus,
      color: 'text-purple-400',
      bgColor: 'bg-purple-500/10 border-purple-500/30',
    },
    {
      num: 4,
      title: t.steps.step4Title,
      desc: t.steps.step4Desc,
      action: t.steps.step4Action,
      icon: PlayCircle,
      color: 'text-emerald-400',
      bgColor: 'bg-emerald-500/10 border-emerald-500/30',
    },
  ];

  return (
    <section id="installation" className="py-24 relative bg-black/40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-3">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full neo-glass border border-amber-500/40 text-amber-400 text-xs font-mono font-bold uppercase tracking-wider">
            <CheckCircle className="w-3.5 h-3.5" />
            <span>{t.steps.tag}</span>
          </div>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-black font-cinzel text-white leading-tight">
            {t.steps.title}
          </h2>
          <p className="text-gray-300 text-base">{t.steps.subtitle}</p>
        </div>

        {/* 4 Steps Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {stepsData.map((step) => {
            const Icon = step.icon;
            const isActive = activeStep === step.num;

            return (
              <div
                key={step.num}
                onClick={() => setActiveStep(step.num)}
                className={`relative p-7 rounded-3xl neo-glass border transition-all cursor-pointer text-left flex flex-col justify-between ${
                  isActive
                    ? 'border-amber-400 shadow-gold-glow scale-[1.02] bg-amber-500/[0.08]'
                    : 'border-white/10 hover:border-cyan-400/50 hover:bg-white/[0.04]'
                }`}
              >
                {/* Step Number Tag */}
                <div className="flex items-center justify-between mb-5">
                  <span className="font-mono text-xs font-bold px-3 py-1 rounded-full bg-white/10 text-gray-300">
                    STEP 0{step.num}
                  </span>
                  <div className={`p-2.5 rounded-2xl border ${step.bgColor} ${step.color}`}>
                    <Icon className="w-5 h-5" />
                  </div>
                </div>

                <div className="space-y-3 mb-6">
                  <h3 className="text-lg font-bold text-white font-cinzel leading-snug">
                    {step.title}
                  </h3>
                  <p className="text-sm text-gray-300 leading-relaxed font-light">{step.desc}</p>
                </div>

                <div className="pt-4 border-t border-white/10">
                  {step.num === 1 ? (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onOpenDownload();
                      }}
                      className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-amber-400 to-yellow-500 text-black font-bold text-xs flex items-center justify-center gap-2 hover:opacity-90 transition-opacity"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>{step.action}</span>
                    </button>
                  ) : (
                    <div className="text-xs font-mono text-gray-400 flex items-center justify-between">
                      <span className="font-semibold text-gray-300">{step.action}</span>
                      <ArrowRight className="w-3.5 h-3.5 text-cyan-400" />
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Global CTA Trigger */}
        <div className="mt-12 text-center">
          <button
            onClick={onOpenDownload}
            className="btn-cyber-glow inline-flex items-center gap-3 px-8 py-4 rounded-2xl bg-gradient-to-r from-cyan-400 to-blue-500 text-black font-black text-sm uppercase tracking-wider shadow-neo-glow hover:scale-105 transition-all cursor-pointer"
          >
            <Download className="w-4 h-4" />
            <span>Open Download Hub (Steam & Mobile)</span>
          </button>
        </div>
      </div>
    </section>
  );
};

'use client';

import React, { useEffect, useState } from 'react';
import { TranslationDict } from '@/lib/i18n';
import { Download, Sparkles, ChevronUp, X } from 'lucide-react';

interface StickyCtaBarProps {
  t: TranslationDict;
  onOpenDownload: () => void;
}

export const StickyCtaBar: React.FC<StickyCtaBarProps> = ({ t, onOpenDownload }) => {
  const [showBar, setShowBar] = useState<boolean>(false);
  const [isDismissed, setIsDismissed] = useState<boolean>(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 400 && !isDismissed) {
        setShowBar(true);
      } else {
        setShowBar(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, [isDismissed]);

  if (!showBar || isDismissed) return null;

  return (
    <div className="fixed bottom-4 left-1/2 -translate-x-1/2 z-[90] w-[95%] max-w-4xl animate-slide-up">
      <div className="p-3 sm:p-4 rounded-2xl neo-glass border border-cyan-500/40 shadow-2xl bg-black/85 backdrop-blur-2xl flex items-center justify-between gap-4">
        {/* Left Info */}
        <div className="flex items-center gap-3 text-left">
          <div className="hidden sm:flex w-10 h-10 rounded-xl bg-cyan-500/20 border border-cyan-500/30 items-center justify-center text-cyan-400 shrink-0">
            <Sparkles className="w-5 h-5" />
          </div>
          <div>
            <div className="text-xs sm:text-sm font-bold text-white font-cinzel line-clamp-1">
              Ragnarok: The New World — Season 2060
            </div>
            <div className="text-[10px] sm:text-xs text-amber-400 font-mono flex items-center gap-2">
              <span>🎁 Free 2060 Starter Pack Active</span>
              <span className="hidden md:inline text-gray-500">|</span>
              <span className="hidden md:inline text-emerald-400">⚡ 30 GB Ultra HD Client</span>
            </div>
          </div>
        </div>

        {/* Right Action */}
        <div className="flex items-center gap-2.5 shrink-0">
          <button
            onClick={onOpenDownload}
            className="btn-cyber-glow px-5 sm:px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 text-black font-black text-xs uppercase tracking-wider shadow-gold-glow hover:scale-105 active:scale-95 transition-all flex items-center gap-2 cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Install Now</span>
          </button>

          <button
            onClick={() => setIsDismissed(true)}
            className="p-2 rounded-xl text-gray-400 hover:text-white transition-colors cursor-pointer"
            title="Dismiss bar"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};

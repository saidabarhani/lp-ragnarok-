'use client';

import React from 'react';
import { TranslationDict } from '@/lib/i18n';
import { Cpu, HardDrive, Laptop, MemoryStick, Monitor, Wifi, CheckCircle2 } from 'lucide-react';

interface SystemRequirementsProps {
  t: TranslationDict;
}

export const SystemRequirements: React.FC<SystemRequirementsProps> = ({ t }) => {
  return (
    <section id="requirements" className="py-20 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-14 space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full neo-glass border border-cyan-500/40 text-cyan-400 text-xs font-mono font-bold uppercase tracking-wider">
            <Laptop className="w-3.5 h-3.5" />
            <span>{t.requirements.tag}</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-black font-cinzel text-white">
            {t.requirements.title}
          </h2>
          <p className="text-gray-300 text-base">{t.requirements.subtitle}</p>
        </div>

        {/* 2 Columns: Minimum vs Recommended */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-5xl mx-auto">
          {/* Minimum Requirements */}
          <div className="p-8 rounded-3xl neo-glass border border-white/10 hover:border-cyan-400/40 transition-all text-left space-y-6">
            <div className="flex items-center justify-between pb-4 border-b border-white/10">
              <div>
                <h3 className="text-xl font-bold text-white font-cinzel">
                  {t.requirements.minTitle}
                </h3>
                <span className="text-xs text-gray-400 font-mono">1080p Standard Preset</span>
              </div>
              <span className="px-3 py-1 rounded-full bg-white/10 text-gray-300 text-xs font-mono">
                Entry Tier
              </span>
            </div>

            <ul className="space-y-4 text-sm font-mono">
              <li className="flex items-start gap-3">
                <Monitor className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                <div>
                  <span className="text-gray-400 block text-xs">Operating System:</span>
                  <strong className="text-white">Windows 10 (64-bit)</strong>
                </div>
              </li>

              <li className="flex items-start gap-3">
                <Cpu className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                <div>
                  <span className="text-gray-400 block text-xs">Processor:</span>
                  <strong className="text-white">Intel Core i5-6400 / AMD Ryzen 3 1200</strong>
                </div>
              </li>

              <li className="flex items-start gap-3">
                <MemoryStick className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <div>
                  <span className="text-gray-400 block text-xs">Memory:</span>
                  <strong className="text-amber-300">12 GB RAM</strong>
                </div>
              </li>

              <li className="flex items-start gap-3">
                <Laptop className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                <div>
                  <span className="text-gray-400 block text-xs">Graphics:</span>
                  <strong className="text-white">
                    NVIDIA GeForce GTX 1060 (6GB) / AMD Radeon RX 580
                  </strong>
                </div>
              </li>

              <li className="flex items-start gap-3">
                <Wifi className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                <div>
                  <span className="text-gray-400 block text-xs">Network:</span>
                  <strong className="text-white">Broadband Internet connection</strong>
                </div>
              </li>

              <li className="flex items-start gap-3">
                <HardDrive className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <div>
                  <span className="text-gray-400 block text-xs">Storage:</span>
                  <strong className="text-amber-300">30 GB available space</strong>
                </div>
              </li>
            </ul>
          </div>

          {/* Recommended Requirements */}
          <div className="p-8 rounded-3xl neo-glass border border-amber-500/40 shadow-gold-glow bg-amber-500/[0.03] text-left space-y-6 relative overflow-hidden">
            <div className="flex items-center justify-between pb-4 border-b border-white/10">
              <div>
                <h3 className="text-xl font-bold text-white font-cinzel">
                  {t.requirements.recTitle}
                </h3>
                <span className="text-xs text-amber-400 font-mono">
                  {t.requirements.recBadge}
                </span>
              </div>
              <span className="px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 text-xs font-mono font-bold border border-amber-500/30">
                Recommended
              </span>
            </div>

            <ul className="space-y-4 text-sm font-mono">
              <li className="flex items-start gap-3">
                <Monitor className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <div>
                  <span className="text-gray-400 block text-xs">Operating System:</span>
                  <strong className="text-white">Windows 10 / 11 (64-bit)</strong>
                </div>
              </li>

              <li className="flex items-start gap-3">
                <Cpu className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <div>
                  <span className="text-gray-400 block text-xs">Processor:</span>
                  <strong className="text-white">Intel Core i7-8700K / AMD Ryzen 5 3600</strong>
                </div>
              </li>

              <li className="flex items-start gap-3">
                <MemoryStick className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <div>
                  <span className="text-gray-400 block text-xs">Memory:</span>
                  <strong className="text-amber-300 text-base">16 GB RAM</strong>
                </div>
              </li>

              <li className="flex items-start gap-3">
                <Laptop className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <div>
                  <span className="text-gray-400 block text-xs">Graphics:</span>
                  <strong className="text-white">
                    NVIDIA GeForce RTX 2060 / AMD Radeon RX 5700
                  </strong>
                </div>
              </li>

              <li className="flex items-start gap-3">
                <Wifi className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <div>
                  <span className="text-gray-400 block text-xs">Network:</span>
                  <strong className="text-white">Broadband Internet connection</strong>
                </div>
              </li>

              <li className="flex items-start gap-3">
                <HardDrive className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <div>
                  <span className="text-gray-400 block text-xs">Storage:</span>
                  <strong className="text-amber-300">30 GB SSD available space</strong>
                </div>
              </li>
            </ul>

            <div className="pt-2 flex items-center gap-2 text-xs text-emerald-400 font-mono">
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              <span>Optimized with DirectX 12 & Vulkan API support</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

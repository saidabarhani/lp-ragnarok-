'use client';

import React from 'react';
import { Moon, Sun } from 'lucide-react';

interface ThemeSwitcherProps {
  theme: 'neo-dark' | 'neo-light';
  onToggleTheme: () => void;
}

export const ThemeSwitcher: React.FC<ThemeSwitcherProps> = ({ theme, onToggleTheme }) => {
  const isDark = theme === 'neo-dark';

  return (
    <button
      onClick={onToggleTheme}
      className="btn btn-sm btn-ghost neo-glass border border-white/10 hover:border-amber-400 gap-1.5 px-3 py-1 rounded-full text-xs font-mono transition-all"
      title={isDark ? 'Switch to 2060 Neo Light Theme' : 'Switch to 2060 Neo Dark Theme'}
      aria-label="Toggle Neo Theme"
    >
      {isDark ? (
        <>
          <Moon className="w-3.5 h-3.5 text-amber-400" />
          <span className="hidden md:inline text-gray-300">Neo Dark 2060</span>
        </>
      ) : (
        <>
          <Sun className="w-3.5 h-3.5 text-amber-500" />
          <span className="hidden md:inline text-gray-700 font-semibold">Neo Light 2060</span>
        </>
      )}
    </button>
  );
};

export type SupportedLocale = 'en' | 'th' | 'id' | 'tl';

export interface TranslationDict {
  nav: {
    world: string;
    features: string;
    classes: string;
    install: string;
    requirements: string;
    community: string;
    playNow: string;
    serverOnline: string;
  };
  hero: {
    badge: string;
    greeting: string;
    title1: string;
    titleHighlight: string;
    title2: string;
    description: string;
    ctaPrimary: string;
    ctaSecondary: string;
    ctaMeta: string;
    statsPlayers: string;
    statsRating: string;
    statsClasses: string;
    starterGiftTitle: string;
    starterGiftDesc: string;
  };
  angles: {
    angleATitle: string;
    angleADesc: string;
    angleBTitle: string;
    angleBDesc: string;
    angleCTitle: string;
    angleCDesc: string;
  };
  objections: {
    tag: string;
    title: string;
    desc: string;
    storageTitle: string;
    storageDesc: string;
    reviewsTitle: string;
    reviewsDesc: string;
    accountTitle: string;
    accountDesc: string;
  };
  steps: {
    tag: string;
    title: string;
    subtitle: string;
    step1Title: string;
    step1Desc: string;
    step1Action: string;
    step2Title: string;
    step2Desc: string;
    step2Action: string;
    step3Title: string;
    step3Desc: string;
    step3Action: string;
    step4Title: string;
    step4Desc: string;
    step4Action: string;
  };
  requirements: {
    tag: string;
    title: string;
    subtitle: string;
    minTitle: string;
    recTitle: string;
    recBadge: string;
    os: string;
    processor: string;
    memory: string;
    graphics: string;
    network: string;
    storage: string;
  };
  classesSection: {
    tag: string;
    title: string;
    desc: string;
    ctaClass: string;
  };
  exitPopup: {
    badge: string;
    title: string;
    desc: string;
    claimBtn: string;
    noThanks: string;
  };
  downloadModal: {
    title: string;
    subtitle: string;
    steamBtn: string;
    googlePlayBtn: string;
    directApkBtn: string;
    pcSpecsNote: string;
  };
}

export const translations: Record<SupportedLocale, TranslationDict> = {
  // 1. ENGLISH (USA / GLOBAL)
  en: {
    nav: {
      world: "World",
      features: "Features",
      classes: "Classes",
      install: "Installation Guide",
      requirements: "System Specs",
      community: "Community",
      playNow: "Install Free",
      serverOnline: "Midgard-Prime 2060 Live",
    },
    hero: {
      badge: "RAGNAROK: THE NEW WORLD • GRAVITY OFFICIAL",
      greeting: "Hello Adventurer, your legend awakens in 2060",
      title1: "Discover the Captivating Universe of",
      titleHighlight: "Ragnarok: The New World",
      title2: "and Install Now!",
      description: "We are thrilled to invite you to immerse yourself in the fantastic universe of Ragnarok, a phenomenon that has charmed millions worldwide! Combining enchanting visuals with immersive freedom, return to Midgard on your own terms with true cross-play on PC and Mobile.",
      ctaPrimary: "Download on Steam & Mobile",
      ctaSecondary: "View 4-Step Quick Guide",
      ctaMeta: "Free-to-Play • Cross-Play PC & Mobile • 30 GB Ultra HD Client",
      statsPlayers: "25M+ Registered Worldwide",
      statsRating: "4.9/5 Active Community",
      statsClasses: "8 Core Classes with Druid",
      starterGiftTitle: "Instant Novice 2060 Starter Pack:",
      starterGiftDesc: "Claim Exclusive Neon Poring Hat + 100x HP/SP Potions + Speed Mount upon First Login!",
    },
    angles: {
      angleATitle: "Return to Midgard, On Your Terms",
      angleADesc: "Step back into iconic cities like Prontera and Geffen, completely reimagined with modern open-world freedom, no locked paths, and seamless exploration.",
      angleBTitle: "Absolute Freedom of Gameplay & Builds",
      angleBDesc: "Never fear making the wrong choice. Switch your class, adjust stat builds, and discover the brand new Druid class alongside 7 legendary archetypes.",
      angleCTitle: "Vast Living World with Guilds & Friends",
      angleCDesc: "You never walk alone. Form powerful guilds, conquer epic open-world MVP Bosses like Baphomet, and wage massive War of Emperium siege battles.",
    },
    objections: {
      tag: "HONEST & TRANSPARENT GAMING",
      title: "Real Answers Before You Install",
      desc: "We value your trust. Here is everything you need to know about size, gameplay, and account setup before entering Midgard.",
      storageTitle: "30 GB Storage on PC",
      storageDesc: "To ensure stunning high-resolution textures, uncompressed orchestral audio, and zero loading screens across Midgard, the PC client requires 30 GB. Pre-load takes only a few minutes on modern broadband.",
      reviewsTitle: "Addressing Community Reviews Honestly",
      reviewsDesc: "We continuously refine performance and balance based on direct player feedback. Recent major patches have stabilized servers and enhanced cross-progression between Steam and Android.",
      accountTitle: "One Unified Gravity / Steam Account",
      accountDesc: "Play seamlessly on PC via Steam and continue on Android/iOS with zero lost progress. One single login synchronizes all characters and items.",
    },
    steps: {
      tag: "FRICTIONLESS ONBOARDING",
      title: "To start your journey, follow these simple instructions",
      subtitle: "From click to first login in 4 quick, transparent steps:",
      step1Title: "Download the Game Client",
      step1Desc: "Head to our official page on Steam or Google Play and click the download button to grab the official verified launcher.",
      step1Action: "Get on Steam / Mobile",
      step2Title: "Install the Game",
      step2Desc: "Once downloaded, launch the installer and follow the on-screen wizard to unpack the 30 GB high-fidelity game world.",
      step2Action: "Automated 90s Setup",
      step3Title: "Create Your Account",
      step3Desc: "After installation, launch the client and fill out the quick registration form or connect directly with your Steam ID.",
      step3Action: "Fast 1-Click Registration",
      step4Title: "Log In & Begin Your Journey",
      step4Desc: "Once registered, log in to receive your instant Novice Starter Pack and immerse yourself in epic quests and unforgettable adventures!",
      step4Action: "Enter Midgard Now",
    },
    requirements: {
      tag: "HARDWARE VERIFICATION",
      title: "System Requirements",
      subtitle: "Optimized for smooth 60+ FPS gameplay on modern and legacy gaming rigs.",
      minTitle: "Minimum Requirements",
      recTitle: "Recommended Specs",
      recBadge: "High Fidelity 2060 Preset",
      os: "Windows 10 (64-bit)",
      processor: "Intel Core i5-6400 / AMD Ryzen 3 1200",
      memory: "12 GB RAM",
      graphics: "NVIDIA GeForce GTX 1060 (6GB) / AMD Radeon RX 580",
      network: "Broadband Internet connection",
      storage: "30 GB available space",
    },
    classesSection: {
      tag: "8 MASTER PROFESSIONS",
      title: "Choose Your Heroic Calling",
      desc: "Featuring the all-new Druid shape-shifter alongside Ragnarok's beloved job branches.",
      ctaClass: "Play This Class",
    },
    exitPopup: {
      badge: "EXCLUSIVE DEPARTURE REWARD",
      title: "Wait, Adventurer! Claim Your 2060 Starter Voucher",
      desc: "Do not venture into Midgard unprepared. Claim your Cyber Poring Hat, 100x Potions, and 200% EXP booster before you go!",
      claimBtn: "Claim Pack & Install Now",
      noThanks: "I'll risk Midgard with empty hands",
    },
    downloadModal: {
      title: "Install Ragnarok: The New World",
      subtitle: "Choose your preferred gaming platform to begin:",
      steamBtn: "Play on Steam (PC)",
      googlePlayBtn: "Get it on Google Play (Android)",
      directApkBtn: "Direct Windows Client (Official)",
      pcSpecsNote: "PC requires 12 GB RAM minimum, 16 GB recommended & 30 GB storage.",
    },
  },

  // 2. THAI (THAILAND - ภาษาไทย)
  th: {
    nav: {
      world: "โลกมิดการ์ด",
      features: "จุดเด่น",
      classes: "สายอาชีพ",
      install: "คู่มือติดตั้ง",
      requirements: "สเปกเครื่อง",
      community: "คอมมูนิตี้",
      playNow: "ดาวน์โหลดฟรี",
      serverOnline: "เซิร์ฟเวอร์เปิดให้บริการ 2060",
    },
    hero: {
      badge: "RAGNAROK: THE NEW WORLD • GRAVITY OFFICIAL",
      greeting: "สวัสดีนักผจญภัย ตำนานของคุณเริ่มต้นแล้วในปี 2060",
      title1: "ค้นพบจักรวาลอันน่าหลงใหลของ",
      titleHighlight: "Ragnarok: The New World",
      title2: "และติดตั้งได้แล้วตอนนี้!",
      description: "เรามีความยินดีเป็นอย่างยิ่งที่จะเชิญคุณดำดิ่งสู่โลกแฟนตาซีของ Ragnarok เกมระดับตำนานที่ครองใจผู้เล่นหลายล้านคนทั่วโลก! ผสานกราฟิกสุดตระการตากับเกมเพลย์อิสระ นำคุณสู่การผจญภัยที่น่าจดจำ ทั้งบน PC และมือถืออย่างแท้จริง",
      ctaPrimary: "ดาวน์โหลดผ่าน Steam และมือถือ",
      ctaSecondary: "ดูวิธีติดตั้ง 4 ขั้นตอนง่ายๆ",
      ctaMeta: "เล่นฟรี 100% • รองรับ PC & มือถือ • ตัวเกม Ultra HD ขนาด 30 GB",
      statsPlayers: "ผู้เล่นลงทะเบียนกว่า 25 ล้านคน",
      statsRating: "4.9/5 คะแนนจากผู้เล่นจริง",
      statsClasses: "8 อาชีพหลักพร้อม Druid ใหม่",
      starterGiftTitle: "ของขวัญต้อนรับนักผจญภัยใหม่ 2060:",
      starterGiftDesc: "รับฟรี! หมวก Poring เรืองแสง + โพชั่น 100 ขวด + สัตว์ขี่เร่งสปีด เมื่อล็อกอินครั้งแรก!",
    },
    angles: {
      angleATitle: "หวนคืนสู่มิดการ์ด ในแบบของคุณเอง",
      angleADesc: "กลับสู่พรอนเทราและเกฟเฟนที่คุ้นเคย ในรูปแบบ Open World ไร้รอยต่อ อิสระเต็มพิกัดโดยไม่ต้องยึดติดกับรูปแบบเดิมๆ",
      angleBTitle: "อิสระในการเล่นและปรับเปลี่ยนสายอาชีพ",
      angleBDesc: "ไม่ต้องกลัวการเลือกผิด เปลี่ยนสายอาชีพและสเตตัสได้ตามใจ พบกับอาชีพใหม่สุดพิเศษ Druid เคียงคู่ 7 คลาสคลาสสิก",
      angleCTitle: "ผจญภัยในโลกกว้างร่วมกับกิลด์และเพื่อนๆ",
      angleCDesc: "การเริ่มต้นไม่จำเป็นต้องโดดเดี่ยว รวมพลังกิลด์ พิชิตบอส MVP ระดับตำนานอย่าง Baphomet และร่วมสงคราม War of Emperium สุดยิ่งใหญ่",
    },
    objections: {
      tag: "เปิดเผยตรงไปตรงมาเพื่อผู้เล่น",
      title: "คำตอบจริงใจก่อนเริ่มดาวน์โหลด",
      desc: "เราให้ความสำคัญกับความไว้วางใจของคุณ นี่คือข้อเท็จจริงเกี่ยวกับขนาดไฟล์และการเชื่อมต่อไอดี",
      storageTitle: "ขนาดไฟล์ 30 GB บน PC",
      storageDesc: "เพื่อคุณภาพกราฟิกความละเอียดสูง เสียงออร์เคสตราสมจริง และโลกมิดการ์ดแบบไร้รอยต่อ ตัวเกมจึงใช้พื้นที่ 30 GB ดาวน์โหลดเร็วผ่านเซิร์ฟเวอร์ความเร็วสูง",
      reviewsTitle: "รับฟังความคิดเห็นเพื่อพัฒนาต่อเนื่อง",
      reviewsDesc: "ทีมงานปรับปรุงประสิทธิภาพเซิร์ฟเวอร์และระบบ Cross-play ระหว่าง Steam และมือถืออย่างต่อเนื่อง เพื่อมอบประสบการณ์ที่ดีที่สุด",
      accountTitle: "หนึ่งไอดี Gravity เล่นได้ทุกแพลตฟอร์ม",
      accountDesc: "ล็อกอินผ่าน Steam บนคอมพิวเตอร์ แล้วหยิบมือถือมาเล่นต่อได้ทันที ข้อมูลตัวละครและไอเทมซิงก์กันแบบเรียลไทม์",
    },
    steps: {
      tag: "ขั้นตอนติดตั้งง่ายๆ",
      title: "เพื่อเริ่มต้นการเดินทางของคุณ โปรดทำตามขั้นตอนง่ายๆ ดังนี้",
      subtitle: "จากคลิกแรกสู่การเข้าเล่นเกมด้วย 4 ขั้นตอนสั้นๆ:",
      step1Title: "ดาวน์โหลดตัวติดตั้งเกม",
      step1Desc: "ไปที่หน้าทางการของเราบน Steam หรือ Google Play แล้วคลิกปุ่มดาวน์โหลดเพื่อรับตัวเปิดเกมอย่างเป็นทางการ",
      step1Action: "รับบน Steam / มือถือ",
      step2Title: "ติดตั้งเกมลงในเครื่อง",
      step2Desc: "เมื่อไฟล์ดาวน์โหลดเสร็จแล้ว ให้เปิดไฟล์และปฏิบัติตามคำแนะนำบนหน้าจอเพื่อติดตั้งไฟล์เกมขนาด 30 GB ให้สมบูรณ์",
      step2Action: "ติดตั้งอัตโนมัติใน 90 วินาที",
      step3Title: "สร้างบัญชีผู้เล่นของคุณ",
      step3Desc: "หลังติดตั้งเสร็จ เปิดเกมขึ้นมาแล้วสร้างบัญชีผู้เล่นของคุณ หรือเข้าสู่ระบบทันทีด้วย Steam / Gravity ID",
      step3Action: "สมัครง่ายใน 1 คลิก",
      step4Title: "เข้าสู่ระบบและเริ่มเล่นได้ทันที",
      step4Desc: "เมื่อสร้างบัญชีเรียบร้อย ล็อกอินเข้าสู่เกม รับแพ็กของขวัญมือใหม่ และปล่อยใจไปกับการผจญภัยอันยิ่งใหญ่ใน Rune-Midgard!",
      step4Action: "เข้าสู่โลก Ragnarok ทันที",
    },
    requirements: {
      tag: "ข้อมูลสเปกคอมพิวเตอร์",
      title: "System Requirements (ความต้องการของระบบ)",
      subtitle: "ออกแบบให้ลื่นไหลทั้งสเปกมาตรฐานและสเปกเกมมิ่งขั้นสูง",
      minTitle: "สเปกขั้นต่ำ (Minimum)",
      recTitle: "สเปกแนะนำ (Recommended)",
      recBadge: "โหมดภาพสวยงามลื่นไหล 60 FPS",
      os: "Windows 10 (64-bit)",
      processor: "Intel Core i5-6400 / AMD Ryzen 3 1200",
      memory: "12 GB RAM",
      graphics: "NVIDIA GeForce GTX 1060 (6GB) / AMD Radeon RX 580",
      network: "การเชื่อมต่ออินเทอร์เน็ตความเร็วสูง",
      storage: "พื้นที่ว่าง 30 GB",
    },
    classesSection: {
      tag: "8 สายอาชีพแห่งเกียรติยศ",
      title: "เลือกเส้นทางวีรบุรุษของคุณ",
      desc: "สัมผัสอาชีพใหม่ Druid ผู้ควบคุมพลังธรรมชาติและกลายร่าง พร้อมคลาสระดับตำนานอีกมากมาย",
      ctaClass: "เลือกเล่นอาชีพนี้",
    },
    exitPopup: {
      badge: "สิทธิพิเศษก่อนออก",
      title: "เดี๋ยวก่อนนักผจญภัย! รับโค้ดสตาร์ทเตอร์ 2060 ฟรี",
      desc: "อย่าเข้าสู่ Midgard มือเปล่า รับหมวก Cyber Poring, โพชั่น 100 ขวด และบัฟ EXP +200% ทันที!",
      claimBtn: "รับของขวัญและติดตั้งเลย",
      noThanks: "ไม่เป็นไร ขอเริ่มผจญภัยด้วยตัวเอง",
    },
    downloadModal: {
      title: "ติดตั้ง Ragnarok: The New World",
      subtitle: "เลือกช่องทางที่คุณต้องการเล่นเพื่อเริ่มดาวน์โหลด:",
      steamBtn: "เล่นผ่าน Steam (PC)",
      googlePlayBtn: "ดาวน์โหลดบน Google Play (Android)",
      directApkBtn: "ดาวน์โหลดตัวติดตั้งตรง PC (Official)",
      pcSpecsNote: "เวอร์ชัน PC ต้องใช้ RAM ขั้นต่ำ 12 GB (แนะนำ 16 GB) และพื้นที่ 30 GB",
    },
  },

  // 3. INDONESIAN (INDONESIA - Bahasa Indonesia)
  id: {
    nav: {
      world: "Dunia",
      features: "Fitur",
      classes: "Kelas",
      install: "Panduan Instalasi",
      requirements: "Spesifikasi",
      community: "Komunitas",
      playNow: "Instal Gratis",
      serverOnline: "Midgard-Prime 2060 Online",
    },
    hero: {
      badge: "RAGNAROK: THE NEW WORLD • GRAVITY RESMI",
      greeting: "Halo Petualang, takdirmu bangkit di era 2060",
      title1: "Jelajahi Alam Semesta Menawan dari",
      titleHighlight: "Ragnarok: The New World",
      title2: "dan Instal Sekarang Juga!",
      description: "Kami sangat senang mengundang Anda untuk terjun ke dalam dunia fantastis Ragnarok, sebuah game yang telah memikat jutaan pemain di seluruh dunia! Memadukan grafis mempesona dengan gameplay mendalam, kembalilah ke Midgard dengan caramu sendiri di PC dan Ponsel.",
      ctaPrimary: "Unduh di Steam & Ponsel",
      ctaSecondary: "Lihat Panduan 4 Langkah Mudah",
      ctaMeta: "100% Gratis • Cross-Play PC & Mobile • Klien Ultra HD 30 GB",
      statsPlayers: "25 Juta+ Pemain Terdaftar",
      statsRating: "4.9/5 Rating Komunitas",
      statsClasses: "8 Kelas Utama Termasuk Druid",
      starterGiftTitle: "Hadiah Spesial Petualang Baru 2060:",
      starterGiftDesc: "Klaim Topi Poring Neon Eksklusif + 100x Potion + Tunggangan Kecepatan saat Login Pertama!",
    },
    angles: {
      angleATitle: "Kembali ke Midgard, Dengan Caramu Sendiri",
      angleADesc: "Jelajahi kembali kota ikonik Prontera dan Geffen dalam dunia terbuka modern yang bebas tanpa batasan kaku.",
      angleBTitle: "Kebebasan Penuh Memilih Kelas dan Gaya Bermain",
      angleBDesc: "Jangan takut salah langkah. Ganti kelas sesukamu dan temukan kelas baru Druid bersama 7 profesi legendaris lainnya.",
      angleCTitle: "Dunia Luas Bersama Teman & Guild",
      angleCDesc: "Awal perjalanan tak perlu sendirian. Bangun guild tangguh, kalahkan Boss MVP seperti Baphomet, dan kuasai War of Emperium.",
    },
    objections: {
      tag: "TRANSPARANSI KEPADA GAMER",
      title: "Jawaban Terbuka Sebelum Anda Menginstal",
      desc: "Kepercayaan Anda adalah prioritas kami. Simak informasi ukuran game dan akun sebelum masuk ke Midgard.",
      storageTitle: "Kapasitas Penyimpanan 30 GB di PC",
      storageDesc: "Untuk menyajikan grafis beresolusi ultra-tinggi dan dunia terbuka tanpa jeda loading, klien PC membutuhkan 30 GB ruang disk.",
      reviewsTitle: "Komitmen Kami Terhadap Ulasan Pemain",
      reviewsDesc: "Kami terus memperbarui dan mengoptimalkan performa server serta stabilitas cross-play antara Steam dan Android secara berkala.",
      accountTitle: "Satu Akun Gravity untuk Semua Perangkat",
      accountDesc: "Main di PC melalui Steam lalu lanjutkan di smartphone kapan saja tanpa kehilangan progres permainan.",
    },
    steps: {
      tag: "PANDUAN MUDAH",
      title: "Untuk memulai perjalanan Anda, ikuti petunjuk sederhana ini",
      subtitle: "Dari klik pertama hingga login perdana dalam 4 langkah cepat:",
      step1Title: "Unduh Klien Game",
      step1Desc: "Kunjungi halaman resmi kami di Steam atau Google Play dan klik tombol unduh untuk mendapatkan installer resmi.",
      step1Action: "Dapatkan di Steam / Ponsel",
      step2Title: "Instal Gamenya",
      step2Desc: "Setelah file terunduh, buka file tersebut dan ikuti panduan di layar untuk menyelesaikan instalasi dunia 30 GB.",
      step2Action: "Instalasi Cepat 90 Detik",
      step3Title: "Buat Akun Anda",
      step3Desc: "Setelah instalasi, jalankan game dan buat akun petualang Anda atau masuk langsung memakai akun Steam / Gravity Anda.",
      step3Action: "Registrasi 1 Klik",
      step4Title: "Masuk & Mulai Bermain",
      step4Desc: "Setelah akun dibuat, masuk ke dalam permainan dan biarkan diri Anda larut dalam petualangan epik di Rune-Midgard!",
      step4Action: "Masuk ke Midgard Sekarang",
    },
    requirements: {
      tag: "PERSYARATAN HARDWARE",
      title: "System Requirements (Kebutuhan Sistem)",
      subtitle: "Dioptimalkan untuk performa stabil 60+ FPS di berbagai perangkat.",
      minTitle: "Spesifikasi Minimum",
      recTitle: "Spesifikasi Rekomendasi",
      recBadge: "Pengalaman Terbaik 2060",
      os: "Windows 10 (64-bit)",
      processor: "Intel Core i5-6400 / AMD Ryzen 3 1200",
      memory: "12 GB RAM",
      graphics: "NVIDIA GeForce GTX 1060 (6GB) / AMD Radeon RX 580",
      network: "Koneksi Internet Broadband",
      storage: "30 GB ruang kosong tersedia",
    },
    classesSection: {
      tag: "8 KELAS KEHORMATAN",
      title: "Pilih Panggilan Heroik Anda",
      desc: "Menghadirkan kelas Druid pengendali elemen alam serta cabang profesi favorit Ragnarok.",
      ctaClass: "Pilih Kelas Ini",
    },
    exitPopup: {
      badge: "HADIAH KHUSUS SEBELUM PERGI",
      title: "Tunggu, Petualang! Klaim Voucher Starter 2060",
      desc: "Jangan masuki Midgard tanpa persiapan. Dapatkan Topi Poring Cyber, 100 Potion, dan buff EXP +200% sekarang!",
      claimBtn: "Klaim Paket & Instal Sekarang",
      noThanks: "Tidak terima kasih, saya akan bermain tanpa bonus",
    },
    downloadModal: {
      title: "Instal Ragnarok: The New World",
      subtitle: "Pilih platform game favorit Anda untuk memulai:",
      steamBtn: "Mainkan di Steam (PC)",
      googlePlayBtn: "Dapatkan di Google Play (Android)",
      directApkBtn: "Unduh Klien Windows Langsung (Resmi)",
      pcSpecsNote: "Versi PC membutuhkan RAM minimum 12 GB (rekomendasi 16 GB) dan ruang 30 GB.",
    },
  },

  // 4. FILIPINO / TAGALOG (PHILIPPINES - Tagalog)
  tl: {
    nav: {
      world: "Mundo",
      features: "Katangian",
      classes: "Klase",
      install: "Gabay sa Pag-install",
      requirements: "Specs",
      community: "Komunidad",
      playNow: "I-install Libre",
      serverOnline: "Midgard-Prime 2060 Live",
    },
    hero: {
      badge: "RAGNAROK: THE NEW WORLD • OPISYAL NA GRAVITY",
      greeting: "Kamusta Bayani, ang iyong kapalaran ay nagsisimula sa 2060",
      title1: "Tuklasin ang Kaakit-akit na Mundo ng",
      titleHighlight: "Ragnarok: The New World",
      title2: "at I-install Na Ngayon!",
      description: "Lubos kaming nagagalak na anyayahan kayong sumabak sa kamangha-manghang mundo ng Ragnarok, isang larong bumihag sa milyun-milyong manlalaro sa buong mundo! Pinagsasama ang nakabibighaning graphics at nakaka-engganyong gameplay, magbalik sa Midgard sa sarili mong diskarte sa PC at Mobile.",
      ctaPrimary: "I-download sa Steam at Mobile",
      ctaSecondary: "Tingnan ang 4 na Madaling Hakbang",
      ctaMeta: "Libreng Laruin • Cross-Play PC & Mobile • 30 GB Ultra HD Client",
      statsPlayers: "25 Milyon+ Rehistradong Manlalaro",
      statsRating: "4.9/5 Rating ng Komunidad",
      statsClasses: "8 Pangunahing Klase kasama ang Druid",
      starterGiftTitle: "Regalo para sa Bagong Manlalaro 2060:",
      starterGiftDesc: "Kunin ang Eksklusibong Neon Poring Hat + 100x Potions + Mount pagkapasok sa First Login!",
    },
    angles: {
      angleATitle: "Bumalik sa Midgard sa Sarili Mong Paraan",
      angleADesc: "Muling lakbayin ang Prontera at Geffen sa isang malawak na open world nang walang kumplikadong limitasyon.",
      angleBTitle: "Ganap na Kalayaan sa Klase at Build",
      angleBDesc: "Huwag matakot magkamali sa pagpili. Malayang palitan ang klase at subukan ang bagong Druid kasama ang 7 klasikong propesyon.",
      angleCTitle: "Mundong Mas Masaya Kasama ang Barkada at Guild",
      angleCDesc: "Hindi mo kailangang magsimula nang mag-isa. Sumali sa guild, labanan ang mga MVP Boss tulad ni Baphomet, at magtagumpay sa War of Emperium.",
    },
    objections: {
      tag: "TAPAT AT MALINAW PARA SA MGA GAMER",
      title: "Totoong Impormasyon Bago Ka Mag-install",
      desc: "Mahalaga sa amin ang tiwala mo. Narito ang dapat mong malaman tungkol sa laki ng laro at paggawa ng account.",
      storageTitle: "30 GB Storage sa PC",
      storageDesc: "Upang maibigay ang pinakamataas na kalidad ng graphics at seamless na mundo nang walang matagal na loading, kailangan ng 30 GB space sa PC.",
      reviewsTitle: "Patuloy na Pagsasaayos Batay sa Feedback",
      reviewsDesc: "Patuloy naming pinapaganda ang katatagan ng server at cross-progression sa pagitan ng Steam at Android para sa walang aberyang paglalaro.",
      accountTitle: "Isang Gravity / Steam Account para sa Lahat",
      accountDesc: "Maglaro sa PC gamit ang Steam at ituloy sa iyong cellphone nang walang mawawalang gamit o progreso.",
    },
    steps: {
      tag: "MADALING PAGSISIMULA",
      title: "Para simulan ang iyong paglalakbay, sundin ang mga simpleng tagubiling ito",
      subtitle: "Mula pag-click hanggang sa unang login sa 4 na mabilis na hakbang:",
      step1Title: "I-download ang Game Client",
      step1Desc: "Pumunta sa aming opisyal na pahina sa Steam o Google Play at pindutin ang download button para makuha ang opisyal na launcher.",
      step1Action: "Kunin sa Steam / Mobile",
      step2Title: "I-install ang Laro",
      step2Desc: "Kapag na-download na ang file, buksan ito at sundin ang mga tagubilin sa screen upang makumpleto ang pag-install ng 30 GB game files.",
      step2Action: "90-Segundong Setup",
      step3Title: "Gawin ang Iyong Account",
      step3Desc: "Pagkatapos ng pag-install, buksan ang laro at lumikha ng iyong account sa pamamagitan ng pagpuno sa mabilisang registration form.",
      step3Action: "1-Click Mabilis na Pagrehistro",
      step4Title: "Mag-login at Simulan ang Paglalaro",
      step4Desc: "Kapag nagawa na ang iyong account, mag-login at hayaang madala ka sa kapana-panabik at maalamat na pakikipagsapalaran!",
      step4Action: "Pumasok sa Midgard Ngayon",
    },
    requirements: {
      tag: "PANGANGAILANGAN SA SISTEMA",
      title: "System Requirements (Specs ng Kompyuter)",
      subtitle: "Gawa para sa maayos na 60+ FPS gameplay sa mga modernong computer.",
      minTitle: "Minimum Requirements",
      recTitle: "Inirerekomendang Specs",
      recBadge: "Pinakamagandang Visuals 2060",
      os: "Windows 10 (64-bit)",
      processor: "Intel Core i5-6400 / AMD Ryzen 3 1200",
      memory: "12 GB RAM",
      graphics: "NVIDIA GeForce GTX 1060 (6GB) / AMD Radeon RX 580",
      network: "Broadband Internet connection",
      storage: "30 GB bakanteng storage",
    },
    classesSection: {
      tag: "8 DAKILANG PROPESYON",
      title: "Piliin ang Iyong Tawag ng Kabayanihan",
      desc: "Tampok ang bagong Druid class kasama ang mga minamahal na propesyon ng Ragnarok.",
      ctaClass: "Laruin ang Klaseng Ito",
    },
    exitPopup: {
      badge: "ESPESYAL NA REGALO BAGO UMALIS",
      title: "Teka Muna, Bayani! Kunin ang Iyong 2060 Starter Pack",
      desc: "Huwag magtungo sa Midgard nang walang sandata! Tanggapin ang Cyber Poring Hat, 100 Potions, at EXP boost ngayon din!",
      claimBtn: "Kunin ang Pack at I-install Na",
      noThanks: "Ayos lang, magsisimula ako nang walang bonus",
    },
    downloadModal: {
      title: "I-install ang Ragnarok: The New World",
      subtitle: "Piliin ang nais mong platform para simulan ang pag-download:",
      steamBtn: "Laruin sa Steam (PC)",
      googlePlayBtn: "Kunin sa Google Play (Android)",
      directApkBtn: "Direktang Windows Client (Opisyal)",
      pcSpecsNote: "Kailangan ng PC ang minimum na 12 GB RAM (16 GB reco) at 30 GB storage.",
    },
  },
};

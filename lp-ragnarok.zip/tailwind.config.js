/** @type {import('tailwindcss').Config} */
module.exports = {
  darkMode: ['class', '[data-theme="neo-dark"]'],
  content: [
    './src/pages/**/*.{js,ts,jsx,tsx,mdx}',
    './src/components/**/*.{js,ts,jsx,tsx,mdx}',
    './src/app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        neo: {
          dark: '#030712',
          card: '#090d16',
          cyan: '#00f2fe',
          cyanGlow: 'rgba(0, 242, 254, 0.4)',
          gold: '#ffd000',
          goldGlow: 'rgba(255, 208, 0, 0.45)',
          purple: '#a855f7',
          pink: '#ff007f',
          surface: '#111827',
          border: 'rgba(255, 255, 255, 0.12)',
        },
        lightNeo: {
          bg: '#f8fafc',
          card: '#ffffff',
          text: '#0f172a',
          cyan: '#0284c7',
          gold: '#d97706',
          border: 'rgba(15, 23, 42, 0.1)',
        }
      },
      fontFamily: {
        cinzel: ['var(--font-cinzel)', 'serif'],
        orbitron: ['var(--font-orbitron)', 'sans-serif'],
        outfit: ['var(--font-outfit)', 'sans-serif'],
      },
      boxShadow: {
        'neo-glow': '0 0 25px rgba(0, 242, 254, 0.4)',
        'gold-glow': '0 0 30px rgba(255, 208, 0, 0.4)',
        'pink-glow': '0 0 25px rgba(255, 0, 127, 0.4)',
      },
      animation: {
        'pulse-glow': 'pulseGlow 2.5s infinite ease-in-out',
        'float-slow': 'floatSlow 4s ease-in-out infinite alternate',
        'spin-slow': 'spin 20s linear infinite',
      },
      keyframes: {
        pulseGlow: {
          '0%, 100%': { opacity: '0.4', transform: 'scale(1)' },
          '50%': { opacity: '0.8', transform: 'scale(1.05)' },
        },
        floatSlow: {
          '0%': { transform: 'translateY(0px)' },
          '100%': { transform: 'translateY(-12px)' },
        }
      }
    },
  },
  plugins: [require('daisyui')],
  daisyui: {
    themes: [
      {
        'neo-dark': {
          'primary': '#00f2fe',
          'secondary': '#ffd000',
          'accent': '#ff007f',
          'neutral': '#111827',
          'base-100': '#030712',
          'info': '#38bdf8',
          'success': '#10b981',
          'warning': '#f59e0b',
          'error': '#f43f5e',
        },
        'neo-light': {
          'primary': '#0284c7',
          'secondary': '#d97706',
          'accent': '#e11d48',
          'neutral': '#334155',
          'base-100': '#f8fafc',
          'info': '#0ea5e9',
          'success': '#059669',
          'warning': '#d97706',
          'error': '#dc2626',
        }
      }
    ],
  },
};
